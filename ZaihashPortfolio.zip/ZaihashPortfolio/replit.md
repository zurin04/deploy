# replit.md

## Overview

This is a modern full-stack portfolio web application for "Zaihash - Builder of the Future" with VPS deployment capability and wallet-based admin panel. The application showcases a futuristic dark theme portfolio with sections for projects, tech stack, and contact information. It includes a comprehensive content management system accessible via wallet authentication. Built with React frontend and Express backend, configured for both Replit development and production VPS deployment with Docker.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom CSS variables for a dark space theme
- **UI Components**: Radix UI components with shadcn/ui design system
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **Build Tool**: Vite for development and production builds
- **Animations**: Framer Motion for smooth animations and interactions

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js 20
- **Development**: tsx for TypeScript execution in development
- **Build**: esbuild for production bundling
- **Session Management**: Connect-pg-simple for PostgreSQL session storage

### Database Architecture
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL 16 (Neon serverless for development, standalone for production)
- **Migrations**: Drizzle Kit for schema management
- **Schema**: 
  - Admin wallet authentication system
  - Articles/blog posts with publishing controls
  - Dynamic site content management
  - Legacy user system (maintained for compatibility)

## Key Components

### Frontend Components
1. **Layout Components**:
   - Navbar with smooth scroll navigation
   - Hero section with particle background animation
   - About section with animated cards
   - Projects showcase with category filtering
   - Tech stack with animated technology cards
   - Connect section with social links
   - Footer

2. **Admin Panel**:
   - Wallet-based authentication system
   - Article management (create, edit, delete, publish)
   - Site content management (social links, text content)
   - Real-time preview and editing interface
   - Publishing controls and featured content flags

3. **UI System**:
   - Complete shadcn/ui component library
   - Custom particle background animation
   - Responsive design with mobile-first approach
   - Dark theme with neon accent colors
   - Web3 wallet integration (MetaMask compatible)

### Backend Components
1. **Storage Layer**: Abstracted storage interface with in-memory implementation
2. **API Routes**: Express router setup for REST endpoints
3. **Database Connection**: Neon serverless PostgreSQL with connection pooling
4. **Development Server**: Vite integration for hot module replacement

## Data Flow

### Frontend Data Flow
1. React components use TanStack Query for API calls
2. Wouter handles client-side routing
3. Form validation with React Hook Form and Zod
4. State updates trigger UI re-renders with animations

### Backend Data Flow
1. Express middleware handles request/response logging
2. Routes use storage interface for data operations
3. Drizzle ORM manages database interactions
4. Session management through PostgreSQL store

### Database Schema
- **Users Table**: Basic user authentication with username and password
- **Schema Management**: Drizzle migrations in `/migrations` directory

## External Dependencies

### Core Dependencies
- **Frontend**: React, Wouter, TanStack Query, Framer Motion
- **Backend**: Express, Drizzle ORM, Neon serverless
- **UI**: Radix UI primitives, Tailwind CSS
- **Build Tools**: Vite, esbuild, tsx
- **Validation**: Zod schema validation
- **Icons**: Lucide React, React Icons

### Development Dependencies
- TypeScript for type safety
- ESLint and Prettier for code quality
- PostCSS for CSS processing

## Deployment Strategy

### Replit Configuration (Development)
- **Environment**: Node.js 20, Web, PostgreSQL 16
- **Development**: `npm run dev` starts the development server
- **Production Build**: `npm run build` creates optimized bundles
- **Production Start**: `npm run start` runs the production server
- **Port Configuration**: Internal port 5000, external port 80
- **Auto-scaling**: Configured for autoscale deployment

### VPS Deployment (Production)
- **One-Click Setup**: `./deploy.sh` script for Ubuntu VPS
- **Containerization**: Docker Compose with PostgreSQL, Nginx, and app containers
- **Domain Configuration**: 
  - Main site: `zaihash.xyz`
  - Admin panel: `admin.zaihash.xyz`
- **SSL**: Automatic HTTPS with self-signed certificates (Let's Encrypt recommended)
- **Database**: Standalone PostgreSQL container with persistent volumes

### Build Process
1. Vite builds the frontend to `dist/public`
2. esbuild bundles the backend to `dist/index.js`
3. Static files served from the dist directory
4. Docker images built for production deployment

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (required)
- `NODE_ENV`: Environment mode (development/production)
- `ADMIN_WALLET_ADDRESS`: Primary admin wallet address
- `POSTGRES_PASSWORD`: Database password for production

## Recent Changes

```
Changelog:
- June 20, 2025. Initial portfolio setup with React frontend and Express backend
- June 20, 2025. Added VPS deployment capability with Docker containers
- June 20, 2025. Implemented wallet-based admin authentication system
- June 20, 2025. Created comprehensive admin panel for content management
- June 20, 2025. Added article management system with publishing controls
- June 20, 2025. Configured domain routing (zaihash.xyz, admin.zaihash.xyz)
- June 20, 2025. Set up one-click deployment script for Ubuntu VPS
```

## Admin Panel Features

### Wallet Authentication
- Primary admin wallet: `0x4aa26202ef61c6c7867046afd4ef2cf4c3dc2afd`
- MetaMask integration for secure login
- Signature verification for access control
- No traditional username/password required

### Content Management
- **Articles**: Create, edit, delete blog posts
- **Publishing Controls**: Draft/published status, featured flags
- **Site Content**: Dynamic management of social links and text content
- **Real-time Updates**: Changes reflect immediately on the main site

### VPS Deployment
- **One-Click Setup**: Execute `./deploy.sh` on Ubuntu VPS
- **Domain Configuration**: Automatic routing for main site and admin subdomain
- **SSL Support**: HTTPS with certificate management
- **Database**: Containerized PostgreSQL with persistent storage

## User Preferences

```
Preferred communication style: Simple, everyday language.
```