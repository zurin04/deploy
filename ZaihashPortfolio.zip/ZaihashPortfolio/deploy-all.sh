#!/bin/bash

# Unified deployment script for both Zaihash Portfolio and Receipt Pro
# Usage: chmod +x deploy-all.sh && ./deploy-all.sh

set -e

echo "🚀 Starting unified deployment for zaihash.xyz and receipt.zaihash.xyz..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Update system
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install Node.js and npm
echo "📦 Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install PM2 for process management
npm install -g pm2

# Install PostgreSQL
echo "🐘 Installing PostgreSQL..."
apt install -y postgresql postgresql-contrib

# Start PostgreSQL service
systemctl start postgresql
systemctl enable postgresql

# Create databases
echo "🔧 Setting up databases..."
sudo -u postgres psql -c "CREATE DATABASE zaihash_portfolio;" 2>/dev/null || echo "Portfolio database already exists"
sudo -u postgres psql -c "CREATE DATABASE receipt_pro;" 2>/dev/null || echo "Receipt Pro database already exists"
sudo -u postgres psql -c "CREATE USER portfoliouser WITH PASSWORD 'securepassword123';" 2>/dev/null || echo "Portfolio user already exists"
sudo -u postgres psql -c "CREATE USER receiptuser WITH PASSWORD 'securepassword123';" 2>/dev/null || echo "Receipt user already exists"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE zaihash_portfolio TO portfoliouser;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE receipt_pro TO receiptuser;"

# Deploy Portfolio Application
echo "📁 Setting up Portfolio application..."
mkdir -p /opt/zaihash-portfolio
cd /opt/zaihash-portfolio

# Check if portfolio files exist
if [ ! -f "package.json" ]; then
    echo "❌ Error: No package.json found in /opt/zaihash-portfolio"
    echo "Please upload your portfolio files to this directory first"
    exit 1
fi

# Set up portfolio environment
cat > .env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://portfoliouser:securepassword123@localhost:5432/zaihash_portfolio
PORT=5000
EOF

# Install portfolio dependencies and build
echo "📦 Installing portfolio dependencies..."
npm ci --production
echo "🔨 Building portfolio application..."
npm run build

# Set up portfolio database schema
echo "🗃️ Setting up portfolio database schema..."
npm run db:push

# Create PM2 ecosystem for portfolio
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'zaihash-portfolio',
    script: 'dist/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
};
EOF

# Deploy Receipt Pro Application
echo "📁 Setting up Receipt Pro application..."
mkdir -p /opt/receipt-pro
cd /opt/receipt-pro

# Check if Receipt Pro files exist
if [ ! -f "package.json" ]; then
    echo "❌ Error: No package.json found in /opt/receipt-pro"
    echo "Please upload your Receipt Pro files to this directory first"
    exit 1
fi

# Set up Receipt Pro environment
cat > .env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://receiptuser:securepassword123@localhost:5432/receipt_pro
PORT=3001
EOF

# Install Receipt Pro dependencies and build
echo "📦 Installing Receipt Pro dependencies..."
npm ci --production
echo "🔨 Building Receipt Pro application..."
npm run build

# Set up Receipt Pro database schema
echo "🗃️ Setting up Receipt Pro database schema..."
npm run db:push

# Create PM2 ecosystem for Receipt Pro
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'receipt-pro',
    script: 'dist/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3001
    }
  }]
};
EOF

# Install and configure Nginx
echo "🌐 Installing and configuring Nginx..."
apt install -y nginx

# Create main Nginx configuration
cat > /etc/nginx/sites-available/zaihash-sites << EOF
# Main portfolio site
server {
    listen 80;
    server_name zaihash.xyz www.zaihash.xyz;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}

# Receipt Pro subdomain
server {
    listen 80;
    server_name receipt.zaihash.xyz;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable the sites and remove default
ln -sf /etc/nginx/sites-available/zaihash-sites /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
nginx -t

# Restart Nginx
systemctl restart nginx

# Set file permissions
chown -R $(whoami):$(whoami) /opt/zaihash-portfolio
chown -R $(whoami):$(whoami) /opt/receipt-pro

# Start applications with PM2
echo "🚀 Starting applications..."

# Start Portfolio
cd /opt/zaihash-portfolio
pm2 delete zaihash-portfolio 2>/dev/null || true
pm2 start ecosystem.config.js

# Start Receipt Pro
cd /opt/receipt-pro
pm2 delete receipt-pro 2>/dev/null || true
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save
pm2 startup

echo "✅ Unified deployment successful!"
echo ""
echo "🌐 Your applications are now accessible at:"
echo "   Portfolio: http://zaihash.xyz"
echo "   Receipt Pro: http://receipt.zaihash.xyz"
echo ""
echo "🔧 To manage applications:"
echo "   View all logs: pm2 logs"
echo "   Portfolio logs: pm2 logs zaihash-portfolio"
echo "   Receipt Pro logs: pm2 logs receipt-pro"
echo "   Restart all: pm2 restart all"
echo "   Status: pm2 status"
echo ""
echo "⚠️  To enable HTTPS for both domains:"
echo "   apt install certbot python3-certbot-nginx"
echo "   certbot --nginx -d zaihash.xyz -d www.zaihash.xyz -d receipt.zaihash.xyz"
echo ""
echo "📋 Applications deployed:"
echo "   ✓ Zaihash Portfolio (zaihash.xyz) - Personal portfolio website"
echo "   ✓ Receipt Pro (receipt.zaihash.xyz) - Professional receipt generation"
echo ""
echo "📁 Application directories:"
echo "   Portfolio: /opt/zaihash-portfolio"
echo "   Receipt Pro: /opt/receipt-pro"
echo ""
echo "🗄️ Databases:"
echo "   Portfolio: zaihash_portfolio (user: portfoliouser)"
echo "   Receipt Pro: receipt_pro (user: receiptuser)"