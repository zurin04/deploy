module.exports = {
  apps: [
    {
      name: 'zaihash-portfolio',
      script: 'tsx',
      args: 'server/index.ts',
      cwd: process.cwd(),
      env: {
        NODE_ENV: 'production',
        PORT: 5000,
        DATABASE_URL: process.env.DATABASE_URL || 'postgresql://portfoliouser:securepass123@localhost:5432/zaihash_portfolio'
      },
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      log_date_format: 'YYYY-MM-DD HH:mm Z',
      error_file: './logs/portfolio-error.log',
      out_file: './logs/portfolio-out.log',
      log_file: './logs/portfolio.log'
    }
  ]
};