module.exports = {
  apps: [
    {
      name: 'zaihash-portfolio',
      script: 'npm',
      args: 'start',
      cwd: '/opt/zaihash-portfolio',
      env: {
        NODE_ENV: 'production',
        PORT: 5000,
        DATABASE_URL: process.env.DATABASE_URL || 'postgresql://portfoliouser:securepass123@localhost:5432/zaihash_portfolio'
      },
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      error_file: '/var/log/pm2/zaihash-portfolio-error.log',
      out_file: '/var/log/pm2/zaihash-portfolio-out.log',
      log_file: '/var/log/pm2/zaihash-portfolio.log'
    },
    {
      name: 'receipt-pro',
      script: 'npm',
      args: 'start',
      cwd: '/opt/receipt-pro',
      env: {
        NODE_ENV: 'production',
        PORT: 3001,
        DATABASE_URL: process.env.DATABASE_URL || 'postgresql://receiptuser:securepass123@localhost:5432/receipt_pro'
      },
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      error_file: '/var/log/pm2/receipt-pro-error.log',
      out_file: '/var/log/pm2/receipt-pro-out.log',
      log_file: '/var/log/pm2/receipt-pro.log'
    }
  ]
};