import { receipts, businessSettings, type Receipt, type InsertReceipt, type BusinessSettings, type InsertBusinessSettings } from "../shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Receipt methods
  getReceipts(): Promise<Receipt[]>;
  getReceipt(id: number): Promise<Receipt | undefined>;
  getReceiptByNumber(receiptNumber: string): Promise<Receipt | undefined>;
  createReceipt(receipt: InsertReceipt): Promise<Receipt>;
  updateReceipt(id: number, receipt: Partial<InsertReceipt>): Promise<Receipt | undefined>;
  deleteReceipt(id: number): Promise<boolean>;
  
  // Business settings methods
  getBusinessSettings(): Promise<BusinessSettings | undefined>;
  updateBusinessSettings(settings: InsertBusinessSettings): Promise<BusinessSettings>;
}

export class DatabaseStorage implements IStorage {
  // Receipt methods
  async getReceipts(): Promise<Receipt[]> {
    return await db.select().from(receipts).orderBy(desc(receipts.createdAt));
  }

  async getReceipt(id: number): Promise<Receipt | undefined> {
    const [result] = await db.select().from(receipts).where(eq(receipts.id, id)).limit(1);
    return result;
  }

  async getReceiptByNumber(receiptNumber: string): Promise<Receipt | undefined> {
    const [result] = await db.select().from(receipts).where(eq(receipts.receiptNumber, receiptNumber)).limit(1);
    return result;
  }

  async createReceipt(insertReceipt: InsertReceipt): Promise<Receipt> {
    const [result] = await db.insert(receipts).values(insertReceipt).returning();
    return result;
  }

  async updateReceipt(id: number, updateData: Partial<InsertReceipt>): Promise<Receipt | undefined> {
    const [result] = await db.update(receipts)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(receipts.id, id))
      .returning();
    return result;
  }

  async deleteReceipt(id: number): Promise<boolean> {
    const result = await db.delete(receipts).where(eq(receipts.id, id));
    return result.rowCount > 0;
  }

  // Business settings methods
  async getBusinessSettings(): Promise<BusinessSettings | undefined> {
    const [result] = await db.select().from(businessSettings).limit(1);
    return result;
  }

  async updateBusinessSettings(settings: InsertBusinessSettings): Promise<BusinessSettings> {
    // First try to get existing settings
    const existing = await this.getBusinessSettings();
    
    if (existing) {
      // Update existing
      const [result] = await db.update(businessSettings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(businessSettings.id, existing.id))
        .returning();
      return result;
    } else {
      // Create new
      const [result] = await db.insert(businessSettings).values(settings).returning();
      return result;
    }
  }
}

export const storage = new DatabaseStorage();