import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Receipts table
export const receipts = pgTable("receipts", {
  id: serial("id").primaryKey(),
  receiptNumber: text("receipt_number").notNull().unique(),
  businessName: text("business_name").notNull(),
  businessAddress: text("business_address"),
  businessPhone: text("business_phone"),
  businessEmail: text("business_email"),
  customerName: text("customer_name"),
  customerPhone: text("customer_phone"),
  customerEmail: text("customer_email"),
  items: json("items").notNull(), // Array of {name, quantity, price, total}
  subtotal: text("subtotal").notNull(),
  tax: text("tax").default("0"),
  discount: text("discount").default("0"),
  total: text("total").notNull(),
  paymentMethod: text("payment_method").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Business settings
export const businessSettings = pgTable("business_settings", {
  id: serial("id").primaryKey(),
  businessName: text("business_name").notNull(),
  address: text("address"),
  phone: text("phone"),
  email: text("email"),
  logo: text("logo"),
  taxRate: text("tax_rate").default("8.25"),
  currency: text("currency").default("USD"),
  receiptFooter: text("receipt_footer").default("Thank you for your business!"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Insert schemas
export const insertReceiptSchema = createInsertSchema(receipts).pick({
  receiptNumber: true,
  businessName: true,
  businessAddress: true,
  businessPhone: true,
  businessEmail: true,
  customerName: true,
  customerPhone: true,
  customerEmail: true,
  items: true,
  subtotal: true,
  tax: true,
  discount: true,
  total: true,
  paymentMethod: true,
  notes: true,
});

export const insertBusinessSettingsSchema = createInsertSchema(businessSettings).pick({
  businessName: true,
  address: true,
  phone: true,
  email: true,
  logo: true,
  taxRate: true,
  currency: true,
  receiptFooter: true,
});

// Types
export type Receipt = typeof receipts.$inferSelect;
export type InsertReceipt = z.infer<typeof insertReceiptSchema>;

export type BusinessSettings = typeof businessSettings.$inferSelect;
export type InsertBusinessSettings = z.infer<typeof insertBusinessSettingsSchema>;