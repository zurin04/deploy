#!/bin/bash

# One-click VPS deployment script for Receipt Pro
# Usage: chmod +x deploy.sh && ./deploy.sh

set -e

echo "🚀 Starting Receipt Pro deployment..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Update system
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install Node.js and npm
echo "📦 Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install PM2 for process management
npm install -g pm2

# Create application directory
echo "📁 Setting up application directory..."
mkdir -p /opt/receipt-pro
cd /opt/receipt-pro

# Copy files if they don't exist (assuming files are already uploaded)
if [ ! -f "package.json" ]; then
    echo "❌ Error: No package.json found. Make sure application files are uploaded to /opt/receipt-pro"
    exit 1
fi

# Install PostgreSQL
echo "🐘 Installing PostgreSQL..."
apt install -y postgresql postgresql-contrib

# Start PostgreSQL service
systemctl start postgresql
systemctl enable postgresql

# Create database and user
echo "🔧 Setting up database..."
sudo -u postgres psql -c "CREATE DATABASE receipt_pro;" 2>/dev/null || echo "Database already exists"
sudo -u postgres psql -c "CREATE USER receiptuser WITH PASSWORD 'securepassword123';" 2>/dev/null || echo "User already exists"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE receipt_pro TO receiptuser;"

# Set up environment variables
echo "⚙️ Configuring environment..."
cat > .env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://receiptuser:securepassword123@localhost:5432/receipt_pro
PORT=5000
EOF

# Install dependencies
echo "📦 Installing dependencies..."
npm ci --production

# Build the application
echo "🔨 Building application..."
npm run build

# Create PM2 ecosystem file
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'receipt-pro',
    script: 'dist/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
};
EOF

# Set up database schema
echo "🗃️ Setting up database schema..."
npm run db:push

# Install and configure Nginx
echo "🌐 Installing Nginx..."
apt install -y nginx

# Create Nginx configuration
cat > /etc/nginx/sites-available/receipt-pro << EOF
server {
    listen 80;
    server_name reciept.zaihash.xyz;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable site
ln -sf /etc/nginx/sites-available/receipt-pro /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Test Nginx configuration
nginx -t

# Restart Nginx
systemctl restart nginx

# Set file permissions
chown -R $(whoami):$(whoami) /opt/receipt-pro

# Start the application with PM2
echo "🚀 Starting application..."
pm2 delete receipt-pro 2>/dev/null || true
pm2 start ecosystem.config.js
pm2 save
pm2 startup

echo "✅ Deployment successful!"
echo ""
echo "🌐 Your Receipt Pro application is now accessible at:"
echo "   http://reciept.zaihash.xyz"
echo ""
echo "🔧 To manage the application:"
echo "   View logs: pm2 logs receipt-pro"
echo "   Restart: pm2 restart receipt-pro"
echo "   Stop: pm2 stop receipt-pro"
echo "   Status: pm2 status"
echo ""
echo "⚠️  To enable HTTPS, install Let's Encrypt:"
echo "   apt install certbot python3-certbot-nginx"
echo "   certbot --nginx -d reciept.zaihash.xyz"
EOF