#!/bin/bash

# One-click VPS deployment script for Zaihash Portfolio
# Usage: chmod +x deploy.sh && ./deploy.sh

set -e

echo "🚀 Starting Zaihash Portfolio deployment..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Update system
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install Docker and Docker Compose
echo "🐳 Installing Docker..."
apt install -y apt-transport-https ca-certificates curl software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | apt-key add -
add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
apt update
apt install -y docker-ce docker-ce-cli containerd.io docker-compose

# Start Docker service
systemctl start docker
systemctl enable docker

# Create application directory
echo "📁 Setting up application directory..."
mkdir -p /opt/zaihash-portfolio
cd /opt/zaihash-portfolio

# Download application files (assuming they're in a git repo)
echo "📥 Downloading application..."
if [ ! -d ".git" ]; then
    # If not already a git repo, clone or copy files
    echo "Please upload your application files to /opt/zaihash-portfolio"
    echo "Or provide a git repository URL to clone from"
    read -p "Git repository URL (or press Enter to skip): " repo_url
    if [ ! -z "$repo_url" ]; then
        git clone "$repo_url" .
    fi
fi

# Set up environment variables
echo "⚙️ Configuring environment..."
if [ ! -f ".env" ]; then
    cat > .env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://postgres:securepassword123@postgres:5432/zaihash_portfolio
POSTGRES_PASSWORD=securepassword123
EOF
fi

# Create SSL directory
mkdir -p ssl

# Generate self-signed certificates (for testing)
echo "🔒 Setting up SSL certificates..."
if [ ! -f "ssl/privkey.pem" ]; then
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout ssl/privkey.pem \
        -out ssl/fullchain.pem \
        -subj "/C=US/ST=State/L=City/O=Organization/CN=zaihash.xyz"
fi

# Create init.sql for database setup
cat > init.sql << EOF
-- Initialize database with admin wallet
INSERT INTO admins (wallet_address, is_active) 
VALUES ('0x4aa26202ef61c6c7867046afd4ef2cf4c3dc2afd', true)
ON CONFLICT (wallet_address) DO NOTHING;

-- Insert default site content
INSERT INTO site_content (key, value, type) VALUES
('hero_title', 'Zaihash - Builder of the Future', 'text'),
('hero_subtitle', 'Self-made builder creating innovative webapps', 'text'),
('about_text', 'I am a passionate developer building the future with AI and modern web technologies.', 'text'),
('github_url', 'https://github.com/zaihash', 'url'),
('twitter_url', 'https://twitter.com/zaihash', 'url'),
('linkedin_url', 'https://linkedin.com/in/zaihash', 'url'),
('email', 'contact@zaihash.xyz', 'text')
ON CONFLICT (key) DO NOTHING;
EOF

# Set file permissions
chown -R www-data:www-data /opt/zaihash-portfolio
chmod +x deploy.sh

# Start the application
echo "🚀 Starting application..."
docker-compose down --remove-orphans 2>/dev/null || true
docker-compose up -d --build

# Wait for services to start
echo "⏳ Waiting for services to start..."
sleep 30

# Check if services are running
if docker-compose ps | grep -q "Up"; then
    echo "✅ Deployment successful!"
    echo ""
    echo "🌐 Your portfolio is now accessible at:"
    echo "   Main site: https://zaihash.xyz"
    echo "   Admin panel: https://admin.zaihash.xyz"
    echo ""
    echo "📋 Admin wallet address: 0x4aa26202ef61c6c7867046afd4ef2cf4c3dc2afd"
    echo ""
    echo "🔧 To manage the application:"
    echo "   View logs: docker-compose logs -f"
    echo "   Restart: docker-compose restart"
    echo "   Stop: docker-compose down"
    echo ""
    echo "⚠️  Important: Replace the self-signed SSL certificates with real ones from Let's Encrypt"
    echo "   Run: certbot --nginx -d zaihash.xyz -d admin.zaihash.xyz"
else
    echo "❌ Deployment failed. Check logs with: docker-compose logs"
    exit 1
fi
EOF