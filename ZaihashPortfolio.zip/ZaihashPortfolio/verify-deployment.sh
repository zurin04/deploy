#!/bin/bash

# Verification script for both applications deployment
echo "🔍 Verifying deployment status..."

# Check if directories exist
echo "📁 Checking application directories..."
if [ -d "/opt/zaihash-portfolio" ]; then
    echo "✅ Portfolio directory exists"
else
    echo "❌ Portfolio directory missing"
fi

if [ -d "/opt/receipt-pro" ]; then
    echo "✅ Receipt Pro directory exists"
else
    echo "❌ Receipt Pro directory missing"
fi

# Check PM2 processes
echo ""
echo "⚙️ Checking PM2 processes..."
if command -v pm2 > /dev/null; then
    pm2 list
else
    echo "❌ PM2 not installed"
fi

# Check Nginx status
echo ""
echo "🌐 Checking Nginx status..."
if systemctl is-active nginx > /dev/null; then
    echo "✅ Nginx is running"
    if [ -f "/etc/nginx/sites-enabled/zaihash-sites" ]; then
        echo "✅ Nginx sites configuration exists"
    else
        echo "❌ Nginx sites configuration missing"
    fi
else
    echo "❌ Nginx is not running"
fi

# Check PostgreSQL status
echo ""
echo "🐘 Checking PostgreSQL status..."
if systemctl is-active postgresql > /dev/null; then
    echo "✅ PostgreSQL is running"
else
    echo "❌ PostgreSQL is not running"
fi

# Check databases
echo ""
echo "🗄️ Checking databases..."
if sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw zaihash_portfolio; then
    echo "✅ Portfolio database exists"
else
    echo "❌ Portfolio database missing"
fi

if sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw receipt_pro; then
    echo "✅ Receipt Pro database exists"
else
    echo "❌ Receipt Pro database missing"
fi

echo ""
echo "🚀 To deploy both applications:"
echo "sudo ./deploy-all.sh"