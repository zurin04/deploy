# Unified Deployment Guide for Zaihash Portfolio & Receipt Pro

This guide explains how to deploy both applications on a single VPS with proper domain routing.

## Prerequisites

- Ubuntu 20.04+ VPS with root access
- Domain names pointing to your VPS:
  - `zaihash.xyz` → Portfolio site
  - `receipt.zaihash.xyz` → Receipt Pro application
- At least 2GB RAM and 20GB storage

## Quick Deployment

### 1. Prepare Application Files

Create directories and upload your files:

```bash
# Create directories
mkdir -p /opt/zaihash-portfolio
mkdir -p /opt/receipt-pro

# Upload your portfolio project files to /opt/zaihash-portfolio
# Upload your Receipt Pro project files to /opt/receipt-pro
```

### 2. Run Unified Deployment Script

```bash
# Make script executable
chmod +x deploy-all.sh

# Run as root
sudo ./deploy-all.sh
```

## What the Script Does

### System Setup
1. Updates Ubuntu packages
2. Installs Node.js 20.x
3. Installs PM2 process manager
4. Installs PostgreSQL database

### Database Configuration
- Creates `zaihash_portfolio` database for portfolio
- Creates `receipt_pro` database for Receipt Pro
- Sets up separate database users with proper permissions

### Application Setup
- Installs dependencies for both applications
- Builds production bundles
- Configures environment variables
- Sets up PM2 process management

### Web Server Configuration
- Configures Nginx reverse proxy
- Routes `zaihash.xyz` → Portfolio (port 5000)
- Routes `receipt.zaihash.xyz` → Receipt Pro (port 3001)

## Post-Deployment

### SSL Certificates (Recommended)

```bash
# Install Certbot
apt install certbot python3-certbot-nginx

# Get SSL certificates for both domains
certbot --nginx -d zaihash.xyz -d www.zaihash.xyz -d receipt.zaihash.xyz
```

### Application Management

```bash
# View all application status
pm2 status

# View logs
pm2 logs                    # All applications
pm2 logs zaihash-portfolio  # Portfolio only
pm2 logs receipt-pro        # Receipt Pro only

# Restart applications
pm2 restart all             # All applications
pm2 restart zaihash-portfolio
pm2 restart receipt-pro

# Stop applications
pm2 stop all
pm2 stop zaihash-portfolio
pm2 stop receipt-pro
```

### Database Management

```bash
# Connect to portfolio database
sudo -u postgres psql -d zaihash_portfolio

# Connect to Receipt Pro database
sudo -u postgres psql -d receipt_pro

# View database tables
\dt
```

## Application Details

### Portfolio Application (zaihash.xyz)
- **Purpose**: Personal portfolio website
- **Port**: 5000
- **Database**: zaihash_portfolio
- **Features**: Project showcase, blog, admin panel

### Receipt Pro (receipt.zaihash.xyz)
- **Purpose**: Professional receipt generation
- **Port**: 3001
- **Database**: receipt_pro
- **Features**: Receipt creation, PDF export, business settings

## Directory Structure

```
/opt/
├── zaihash-portfolio/          # Portfolio application
│   ├── dist/                   # Built files
│   ├── node_modules/           # Dependencies
│   ├── ecosystem.config.js     # PM2 configuration
│   └── .env                    # Environment variables
└── receipt-pro/                # Receipt Pro application
    ├── dist/                   # Built files
    ├── node_modules/           # Dependencies
    ├── ecosystem.config.js     # PM2 configuration
    └── .env                    # Environment variables
```

## Environment Variables

### Portfolio (.env)
```
NODE_ENV=production
DATABASE_URL=postgresql://portfoliouser:securepassword123@localhost:5432/zaihash_portfolio
PORT=5000
```

### Receipt Pro (.env)
```
NODE_ENV=production
DATABASE_URL=postgresql://receiptuser:securepassword123@localhost:5432/receipt_pro
PORT=3001
```

## Troubleshooting

### Check Application Status
```bash
pm2 status
pm2 logs
```

### Check Nginx Status
```bash
systemctl status nginx
nginx -t
```

### Check Database Connection
```bash
sudo -u postgres psql -l
```

### Restart Services
```bash
# Restart applications
pm2 restart all

# Restart Nginx
systemctl restart nginx

# Restart PostgreSQL
systemctl restart postgresql
```

## Security Notes

- Database passwords are set to default values - change them in production
- Enable firewall and configure proper security rules
- Use SSL certificates for HTTPS
- Regularly update system packages and dependencies
- Monitor application logs for security issues

## Backup Strategy

### Database Backups
```bash
# Portfolio backup
sudo -u postgres pg_dump zaihash_portfolio > portfolio_backup.sql

# Receipt Pro backup
sudo -u postgres pg_dump receipt_pro > receipt_backup.sql
```

### Application Backups
```bash
# Backup application files
tar -czf portfolio_backup.tar.gz /opt/zaihash-portfolio
tar -czf receipt_backup.tar.gz /opt/receipt-pro
```

This deployment setup provides a robust, scalable solution for hosting both applications on a single VPS with proper domain routing and SSL support.