import { users, admins, articles, projects, siteContent, receipts, businessSettings, type User, type InsertUser, type Admin, type InsertAdmin, type Article, type InsertArticle, type Project, type InsertProject, type SiteContent, type InsertSiteContent, type Receipt, type InsertReceipt, type BusinessSettings, type InsertBusinessSettings } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User methods (legacy)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Admin methods
  getAdminByWallet(walletAddress: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  
  // Receipt methods
  getReceipts(): Promise<Receipt[]>;
  getReceipt(id: number): Promise<Receipt | undefined>;
  getReceiptByNumber(receiptNumber: string): Promise<Receipt | undefined>;
  createReceipt(receipt: InsertReceipt): Promise<Receipt>;
  updateReceipt(id: number, receipt: Partial<InsertReceipt>): Promise<Receipt | undefined>;
  deleteReceipt(id: number): Promise<boolean>;
  
  // Business settings methods
  getBusinessSettings(): Promise<BusinessSettings | undefined>;
  updateBusinessSettings(settings: InsertBusinessSettings): Promise<BusinessSettings>;
  
  // Article methods
  getArticles(): Promise<Article[]>;
  getArticle(id: number): Promise<Article | undefined>;
  getArticleBySlug(slug: string): Promise<Article | undefined>;
  getPublishedArticles(): Promise<Article[]>;
  createArticle(article: InsertArticle): Promise<Article>;
  updateArticle(id: number, article: Partial<InsertArticle>): Promise<Article | undefined>;
  deleteArticle(id: number): Promise<boolean>;
  
  // Project methods
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  getPublishedProjects(): Promise<Project[]>;
  getFeaturedProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  
  // Site content methods
  getSiteContent(): Promise<SiteContent[]>;
  getSiteContentByKey(key: string): Promise<SiteContent | undefined>;
  updateSiteContent(key: string, value: string, type: string): Promise<SiteContent>;
}

export class DatabaseStorage implements IStorage {
  // User methods (legacy)
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Admin methods
  async getAdminByWallet(walletAddress: string): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.walletAddress, walletAddress.toLowerCase()));
    return admin || undefined;
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    const [admin] = await db.insert(admins).values({
      ...insertAdmin,
      walletAddress: insertAdmin.walletAddress.toLowerCase()
    }).returning();
    return admin;
  }

  // Article methods
  async getArticles(): Promise<Article[]> {
    return await db.select().from(articles).orderBy(desc(articles.createdAt));
  }

  async getArticle(id: number): Promise<Article | undefined> {
    const [article] = await db.select().from(articles).where(eq(articles.id, id));
    return article || undefined;
  }

  async getArticleBySlug(slug: string): Promise<Article | undefined> {
    const [article] = await db.select().from(articles).where(eq(articles.slug, slug));
    return article || undefined;
  }

  async getPublishedArticles(): Promise<Article[]> {
    return await db.select().from(articles)
      .where(eq(articles.published, true))
      .orderBy(desc(articles.createdAt));
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const [article] = await db.insert(articles).values(insertArticle).returning();
    return article;
  }

  async updateArticle(id: number, updateData: Partial<InsertArticle>): Promise<Article | undefined> {
    const [article] = await db.update(articles)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(articles.id, id))
      .returning();
    return article || undefined;
  }

  async deleteArticle(id: number): Promise<boolean> {
    const result = await db.delete(articles).where(eq(articles.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Project methods
  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.orderIndex), desc(projects.createdAt));
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async getPublishedProjects(): Promise<Project[]> {
    return await db.select().from(projects)
      .where(eq(projects.published, true))
      .orderBy(desc(projects.orderIndex), desc(projects.createdAt));
  }

  async getFeaturedProjects(): Promise<Project[]> {
    return await db.select().from(projects)
      .where(eq(projects.featured, true))
      .orderBy(desc(projects.orderIndex), desc(projects.createdAt));
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db.insert(projects).values(insertProject).returning();
    return project;
  }

  async updateProject(id: number, updateData: Partial<InsertProject>): Promise<Project | undefined> {
    const [project] = await db.update(projects)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project || undefined;
  }

  async deleteProject(id: number): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Site content methods
  async getSiteContent(): Promise<SiteContent[]> {
    return await db.select().from(siteContent);
  }

  async getSiteContentByKey(key: string): Promise<SiteContent | undefined> {
    const [content] = await db.select().from(siteContent).where(eq(siteContent.key, key));
    return content || undefined;
  }

  async updateSiteContent(key: string, value: string, type: string): Promise<SiteContent> {
    const existing = await this.getSiteContentByKey(key);
    
    if (existing) {
      const [updated] = await db.update(siteContent)
        .set({ value, type, updatedAt: new Date() })
        .where(eq(siteContent.key, key))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(siteContent)
        .values({ key, value, type })
        .returning();
      return created;
    }
  }

  // Receipt methods
  async getReceipts(): Promise<Receipt[]> {
    return await db.select().from(receipts).orderBy(desc(receipts.createdAt));
  }

  async getReceipt(id: number): Promise<Receipt | undefined> {
    const [result] = await db.select().from(receipts).where(eq(receipts.id, id)).limit(1);
    return result;
  }

  async getReceiptByNumber(receiptNumber: string): Promise<Receipt | undefined> {
    const [result] = await db.select().from(receipts).where(eq(receipts.receiptNumber, receiptNumber)).limit(1);
    return result;
  }

  async createReceipt(insertReceipt: InsertReceipt): Promise<Receipt> {
    const [result] = await db.insert(receipts).values(insertReceipt).returning();
    return result;
  }

  async updateReceipt(id: number, updateData: Partial<InsertReceipt>): Promise<Receipt | undefined> {
    const [result] = await db.update(receipts)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(receipts.id, id))
      .returning();
    return result;
  }

  async deleteReceipt(id: number): Promise<boolean> {
    const result = await db.delete(receipts).where(eq(receipts.id, id));
    return result.rowCount > 0;
  }

  // Business settings methods
  async getBusinessSettings(): Promise<BusinessSettings | undefined> {
    const [result] = await db.select().from(businessSettings).limit(1);
    return result;
  }

  async updateBusinessSettings(settings: InsertBusinessSettings): Promise<BusinessSettings> {
    // First try to get existing settings
    const existing = await this.getBusinessSettings();
    
    if (existing) {
      // Update existing
      const [result] = await db.update(businessSettings)
        .set({ ...settings, updatedAt: new Date() })
        .where(eq(businessSettings.id, existing.id))
        .returning();
      return result;
    } else {
      // Create new
      const [result] = await db.insert(businessSettings).values(settings).returning();
      return result;
    }
  }
}

export const storage = new DatabaseStorage();
