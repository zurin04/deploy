# VPS Deployment Guide for Receipt Pro

## Prerequisites
- Ubuntu 20.04+ VPS with root access
- Domain `receipt.zaihash.xyz` pointing to your VPS IP
- At least 1GB RAM and 10GB storage

## Quick Deployment Steps

1. **Upload Files to VPS**
   ```bash
   # Create directory on VPS
   mkdir -p /opt/receipt-pro
   
   # Upload your project files (extract zip in this directory)
   cd /opt/receipt-pro
   ```

2. **Run Deployment Script**
   ```bash
   # Make script executable
   chmod +x deploy.sh
   
   # Run as root
   sudo ./deploy.sh
   ```

## What the Script Does

1. Installs Node.js 20.x
2. Installs PostgreSQL and creates database
3. Installs PM2 for process management
4. Installs and configures Nginx
5. Builds and starts the application
6. Sets up reverse proxy for your domain

## Post-Deployment

After successful deployment:
- Your app will be available at: `http://receipt.zaihash.xyz`
- Admin panel accessible at: `http://reciept.zaihash.xyz/admin`

## SSL Certificate (Optional)
To enable HTTPS:
```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d receipt.zaihash.xyz
```

## Troubleshooting

### Check Application Status
```bash
pm2 status
pm2 logs receipt-pro
```

### Check Nginx Status
```bash
systemctl status nginx
nginx -t
```

### Check Database
```bash
sudo -u postgres psql -d receipt_pro -c "\dt"
```

### Restart Services
```bash
# Restart app
pm2 restart receipt-pro

# Restart nginx
systemctl restart nginx

# Restart database
systemctl restart postgresql
```

## Admin Access
The admin panel requires wallet authentication. Connect your wallet at `/admin` to access content management features.

## Files Structure on VPS
```
/opt/receipt-pro/
├── dist/              # Built application
├── node_modules/      # Dependencies  
├── ecosystem.config.js # PM2 configuration
├── .env              # Environment variables
└── deploy.sh         # Deployment script
```