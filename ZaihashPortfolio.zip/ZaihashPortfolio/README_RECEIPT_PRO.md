# Receipt Pro - Professional Receipt Generation

A modern web application for creating, managing, and printing professional receipts. Built with React, Node.js, and PostgreSQL.

## Features

### Receipt Generation
- **Interactive Form**: Easy-to-use form for creating receipts
- **Real-time Preview**: See receipt as you type
- **Itemized Billing**: Add multiple items with quantities and prices
- **Automatic Calculations**: Subtotal, tax, and total calculations
- **Customer Information**: Store customer details for future reference

### Receipt Management
- **Receipt History**: View all created receipts
- **Search & Filter**: Find receipts by number, customer, or business name
- **PDF Export**: Download receipts as PDF files
- **Print Support**: Direct printing capability

### Business Configuration
- **Business Settings**: Configure company information
- **Tax Configuration**: Set tax rates and currency
- **Custom Branding**: Add business logo and footer messages
- **Address Management**: Store business address and contact info

### Dashboard & Analytics
- **Revenue Tracking**: Monitor total revenue and monthly sales
- **Receipt Statistics**: Track number of receipts created
- **Recent Activity**: Quick view of latest transactions
- **Quick Actions**: Fast access to common features

## Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Node.js, Express, TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Components**: Radix UI, Lucide Icons
- **State Management**: TanStack Query
- **Routing**: Wouter
- **Validation**: Zod schemas

## Database Schema

### Receipts Table
- Receipt number (unique)
- Business and customer information
- Itemized products/services (JSON)
- Financial calculations (subtotal, tax, total)
- Payment method and notes
- Timestamps

### Business Settings Table
- Company information
- Contact details
- Tax configuration
- Branding elements
- Currency settings

## API Endpoints

### Receipt Operations
- `GET /api/receipts` - List all receipts
- `POST /api/receipts` - Create new receipt
- `GET /api/receipts/:id` - Get specific receipt
- `PUT /api/receipts/:id` - Update receipt
- `DELETE /api/receipts/:id` - Delete receipt

### Business Settings
- `GET /api/business-settings` - Get business configuration
- `PUT /api/business-settings` - Update business settings

## Deployment

The application is configured for deployment to `reciept.zaihash.xyz` with:
- PM2 process management
- Nginx reverse proxy
- PostgreSQL database
- SSL certificate support
- Ubuntu VPS compatibility

## Usage

1. **Setup Business Information**: Configure your business details in settings
2. **Create Receipts**: Use the generator to create professional receipts
3. **Manage History**: View, search, and export past receipts
4. **Print/Share**: Generate PDFs or print directly from browser

## Security

- Input validation with Zod schemas
- SQL injection protection via Drizzle ORM
- Type-safe API endpoints
- Environment variable configuration

This Receipt Pro application provides a complete solution for small businesses needing professional receipt generation and management capabilities.