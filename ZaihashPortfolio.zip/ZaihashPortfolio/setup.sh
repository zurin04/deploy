#!/bin/bash

# One-Click Setup for Zaihash Portfolio & Receipt Pro
# Usage: sudo ./setup.sh

set -e

echo "🚀 One-Click Setup Starting..."
echo "This will deploy both zaihash.xyz and receipt.zaihash.xyz"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Please run as root: sudo ./setup.sh"
    exit 1
fi

# Get the current directory (where the script is run from)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Check if we have the portfolio files
if [ ! -f "package.json" ]; then
    echo "❌ No package.json found. Please run this script from your extracted Replit project directory."
    exit 1
fi

echo "📦 Updating system..."
apt update && apt upgrade -y

echo "📦 Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

echo "📦 Installing PM2..."
npm install -g pm2

# Install tsx for TypeScript execution
npm install -g tsx

echo "🐘 Installing PostgreSQL..."
apt install -y postgresql postgresql-contrib
systemctl start postgresql
systemctl enable postgresql

echo "🗄️ Setting up databases..."
sudo -u postgres psql -c "CREATE DATABASE zaihash_portfolio;" 2>/dev/null || true
sudo -u postgres psql -c "CREATE DATABASE receipt_pro;" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER portfoliouser WITH PASSWORD 'securepass123';" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER receiptuser WITH PASSWORD 'securepass123';" 2>/dev/null || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE zaihash_portfolio TO portfoliouser;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE receipt_pro TO receiptuser;"

echo "📁 Preparing application directories..."
mkdir -p /opt/zaihash-portfolio
mkdir -p /opt/receipt-pro

echo "📦 Copying portfolio files..."
rsync -av --exclude=receipt-pro --exclude=node_modules --exclude=dist . /opt/zaihash-portfolio/

echo "📦 Copying Receipt Pro files..."
if [ -d "receipt-pro" ]; then
    cp -r receipt-pro/* /opt/receipt-pro/
else
    echo "⚠️ No receipt-pro directory found, creating minimal Receipt Pro..."
    mkdir -p /opt/receipt-pro
    cat > /opt/receipt-pro/package.json << 'EOF'
{
  "name": "receipt-pro",
  "version": "1.0.0",
  "scripts": {
    "build": "echo 'Build complete'",
    "start": "node index.js",
    "db:push": "echo 'DB push complete'"
  },
  "dependencies": {
    "express": "^4.18.2"
  }
}
EOF
    cat > /opt/receipt-pro/index.js << 'EOF'
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.static('public'));

app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
        <title>Receipt Pro - Coming Soon</title>
        <style>
            body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
            .container { max-width: 600px; margin: 0 auto; }
            h1 { color: #333; }
            p { color: #666; font-size: 18px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Receipt Pro</h1>
            <p>Professional Receipt Generation System</p>
            <p>Coming Soon to receipt.zaihash.xyz</p>
        </div>
    </body>
    </html>
  `);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Receipt Pro server running on port ${PORT}`);
});
EOF
fi

echo "⚙️ Setting up Portfolio application..."
cd /opt/zaihash-portfolio

cat > .env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://portfoliouser:securepass123@localhost:5432/zaihash_portfolio
PORT=5000
EOF

npm install --production
npm run build 2>/dev/null || echo "Build step skipped"
npm run db:push 2>/dev/null || echo "DB push skipped"

# Determine the correct script path
SCRIPT_PATH="server/index.js"
if [ -f "dist/index.js" ]; then
    SCRIPT_PATH="dist/index.js"
elif [ -f "server/index.ts" ]; then
    SCRIPT_PATH="server/index.ts"
fi

cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'zaihash-portfolio',
    script: '$SCRIPT_PATH',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    }
  }]
};
EOF

echo "⚙️ Setting up Receipt Pro application..."
cd /opt/receipt-pro

cat > .env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://receiptuser:securepass123@localhost:5432/receipt_pro
PORT=3001
EOF

npm install --production
npm run build 2>/dev/null || echo "Build step skipped"
npm run db:push 2>/dev/null || echo "DB push skipped"

cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'receipt-pro',
    script: 'index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3001
    }
  }]
};
EOF

echo "🌐 Installing and configuring Nginx..."
apt install -y nginx

cat > /etc/nginx/sites-available/zaihash-sites << 'EOF'
server {
    listen 80;
    server_name zaihash.xyz www.zaihash.xyz;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}

server {
    listen 80;
    server_name receipt.zaihash.xyz;
    
    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

ln -sf /etc/nginx/sites-available/zaihash-sites /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

nginx -t
systemctl restart nginx

echo "🚀 Starting applications..."
# Set proper ownership for the applications
if id "www-data" &>/dev/null; then
    chown -R www-data:www-data /opt/zaihash-portfolio
    chown -R www-data:www-data /opt/receipt-pro
else
    chown -R $(whoami):$(whoami) /opt/zaihash-portfolio
    chown -R $(whoami):$(whoami) /opt/receipt-pro
fi

cd /opt/zaihash-portfolio
pm2 delete zaihash-portfolio 2>/dev/null || true
pm2 start ecosystem.config.js

cd /opt/receipt-pro
pm2 delete receipt-pro 2>/dev/null || true
pm2 start ecosystem.config.js

pm2 save
pm2 startup

echo ""
echo "✅ One-Click Setup Complete!"
echo ""
echo "🌐 Your applications are live:"
echo "   Portfolio: http://zaihash.xyz"
echo "   Receipt Pro: http://receipt.zaihash.xyz"
echo ""
echo "🔧 Management commands:"
echo "   pm2 status    - View application status"
echo "   pm2 logs      - View all logs"
echo "   pm2 restart all - Restart both applications"
echo ""
echo "🔒 Enable HTTPS (optional):"
echo "   apt install certbot python3-certbot-nginx"
echo "   certbot --nginx -d zaihash.xyz -d receipt.zaihash.xyz"
echo ""
echo "📋 Setup completed successfully!"