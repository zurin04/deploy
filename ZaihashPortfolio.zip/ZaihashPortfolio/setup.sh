#!/bin/bash

# One-Click VPS Setup for Zaihash Portfolio
# Usage: sudo ./setup.sh

set -e

echo "🚀 Starting Zaihash Portfolio deployment..."

if [ "$EUID" -ne 0 ]; then
    echo "Please run as root: sudo ./setup.sh"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# System packages
echo "📦 Installing system packages..."
apt update && apt upgrade -y
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs postgresql postgresql-contrib nginx build-essential
npm install -g pm2 tsx

# PostgreSQL setup
echo "🗄️ Setting up database..."
systemctl start postgresql
systemctl enable postgresql
sudo -u postgres psql -c "CREATE DATABASE zaihash_portfolio;" 2>/dev/null || true
sudo -u postgres psql -c "CREATE USER portfoliouser WITH PASSWORD 'securepass123';" 2>/dev/null || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE zaihash_portfolio TO portfoliouser;"

# Application setup
echo "📦 Installing dependencies..."
npm install

# Environment setup
cat > .env << EOF
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://portfoliouser:securepass123@localhost:5432/zaihash_portfolio
EOF

# Database schema
echo "🗄️ Setting up database schema..."
npm run db:push

# Sample data
echo "📊 Adding sample content..."
sudo -u postgres psql zaihash_portfolio << 'EOSQL'
INSERT INTO projects (title, description, short_description, image_url, live_url, github_url, technologies, category, featured, published, order_index) VALUES 
('AI Receipt Generator', 'A modern receipt generation system powered by AI that creates professional receipts with smart itemization and automatic calculations. Features include PDF export, business branding, and comprehensive reporting.', 'AI-powered receipt generation with smart features', '/api/placeholder/600/400', 'https://receipt.zaihash.xyz', 'https://github.com/zaihash/receipt-pro', ARRAY['React', 'Node.js', 'PostgreSQL', 'AI/ML', 'TypeScript'], 'Web Application', true, true, 1),
('Blockchain Portfolio Tracker', 'Advanced cryptocurrency portfolio management system with real-time price tracking, DeFi integration, and comprehensive analytics. Built with Web3 technologies and modern React architecture.', 'Advanced crypto portfolio tracking and analytics', '/api/placeholder/600/400', '#', '#', ARRAY['React', 'Web3', 'Ethereum', 'Chart.js', 'TypeScript'], 'Blockchain', true, true, 2),
('Neural Network Visualizer', 'Interactive machine learning model visualization tool that helps understand neural network architectures and training processes. Features real-time data flow visualization and model performance metrics.', 'Interactive ML model visualization and analysis', '/api/placeholder/600/400', '#', '#', ARRAY['Python', 'TensorFlow', 'D3.js', 'React', 'WebGL'], 'AI/ML', true, true, 3)
ON CONFLICT DO NOTHING;

INSERT INTO articles (title, content, excerpt, slug, published, featured, tags) VALUES 
('Building the Future with AI and Web3', 'The convergence of artificial intelligence and blockchain technology is creating unprecedented opportunities for innovation. In this article, I explore how these technologies complement each other and share insights from building cutting-edge applications that leverage both domains.', 'Exploring the intersection of AI and blockchain technology in modern development', 'ai-web3-future', true, true, ARRAY['AI', 'Web3', 'Blockchain', 'Innovation']),
('From Zero to Full-Stack: My Development Journey', 'Starting as a self-taught developer, I''ve learned that the path to mastery requires continuous learning, experimentation, and building real-world solutions. Here''s my journey and the lessons learned along the way.', 'A personal reflection on the self-taught developer journey', 'zero-to-fullstack-journey', true, true, ARRAY['Career', 'Learning', 'Full-Stack', 'Personal']),
('Optimizing PostgreSQL for High-Performance Applications', 'Database optimization is crucial for scalable applications. This deep dive covers advanced PostgreSQL techniques, indexing strategies, and performance monitoring that have helped me build faster, more reliable systems.', 'Advanced PostgreSQL optimization techniques and best practices', 'postgresql-optimization-guide', true, false, ARRAY['Database', 'PostgreSQL', 'Performance', 'Backend'])
ON CONFLICT DO NOTHING;

INSERT INTO site_content (key, value, type) VALUES 
('about_title', 'The Journey of Innovation', 'text'),
('about_description', 'Self-taught developer with a passion for pushing the boundaries of technology. From humble beginnings to building cutting-edge applications that solve real-world problems. Specializing in AI integration, blockchain solutions, and full-stack development with a focus on user experience and scalability.', 'text'),
('hero_tagline', 'Builder of the Future', 'text'),
('contact_email', 'hello@zaihash.xyz', 'text'),
('contact_location', 'Building from anywhere', 'text'),
('tech_stack_title', 'Technology Arsenal', 'text'),
('tech_stack_description', 'Leveraging modern technologies to build scalable, innovative solutions', 'text')
ON CONFLICT DO NOTHING;
EOSQL

# PM2 startup
echo "🚀 Starting application..."
pm2 delete zaihash-portfolio 2>/dev/null || true
pm2 start ecosystem.config.js
pm2 save
pm2 startup

# Nginx configuration
echo "🌐 Configuring web server..."
cat > /etc/nginx/sites-available/zaihash << EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

ln -sf /etc/nginx/sites-available/zaihash /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "✅ Deployment completed successfully!"
echo "🌐 Portfolio is live at: http://$(curl -s ifconfig.me)"
echo "📊 Check status: pm2 status"
echo "📋 View logs: pm2 logs zaihash-portfolio"

pm2 status