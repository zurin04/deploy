import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Admin wallet addresses (for authentication)
export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull().unique(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Articles/Blog posts
export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  excerpt: text("excerpt"),
  featured: boolean("featured").default(false),
  published: boolean("published").default(false),
  tags: text("tags").array(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Projects portfolio
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  shortDescription: text("short_description"),
  imageUrl: text("image_url"),
  liveUrl: text("live_url"),
  githubUrl: text("github_url"),
  technologies: text("technologies").array(),
  category: text("category").notNull(), // 'webapp', 'mobile', 'ai', 'blockchain', etc.
  featured: boolean("featured").default(false),
  published: boolean("published").default(false),
  orderIndex: integer("order_index").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Receipts table
export const receipts = pgTable("receipts", {
  id: serial("id").primaryKey(),
  receiptNumber: text("receipt_number").notNull().unique(),
  businessName: text("business_name").notNull(),
  businessAddress: text("business_address"),
  businessPhone: text("business_phone"),
  businessEmail: text("business_email"),
  customerName: text("customer_name"),
  customerPhone: text("customer_phone"),
  customerEmail: text("customer_email"),
  items: json("items").notNull(), // Array of {name, quantity, price, total}
  subtotal: text("subtotal").notNull(),
  tax: text("tax").default("0"),
  discount: text("discount").default("0"),
  total: text("total").notNull(),
  paymentMethod: text("payment_method").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Business settings
export const businessSettings = pgTable("business_settings", {
  id: serial("id").primaryKey(),
  businessName: text("business_name").notNull(),
  address: text("address"),
  phone: text("phone"),
  email: text("email"),
  logo: text("logo"),
  taxRate: text("tax_rate").default("0"),
  currency: text("currency").default("USD"),
  receiptFooter: text("receipt_footer"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Site content (about, social links, etc.)
export const siteContent = pgTable("site_content", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(), // e.g., 'hero_title', 'about_text', 'github_url'
  value: text("value").notNull(),
  type: text("type").notNull(), // 'text', 'url', 'json', 'html'
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const articlesRelations = relations(articles, ({ one }) => ({}));

// Insert schemas
export const insertAdminSchema = createInsertSchema(admins).pick({
  walletAddress: true,
});

export const insertArticleSchema = createInsertSchema(articles).pick({
  title: true,
  slug: true,
  content: true,
  excerpt: true,
  featured: true,
  published: true,
  tags: true,
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  title: true,
  description: true,
  shortDescription: true,
  imageUrl: true,
  liveUrl: true,
  githubUrl: true,
  technologies: true,
  category: true,
  featured: true,
  published: true,
  orderIndex: true,
});

export const insertReceiptSchema = createInsertSchema(receipts).pick({
  receiptNumber: true,
  businessName: true,
  businessAddress: true,
  businessPhone: true,
  businessEmail: true,
  customerName: true,
  customerPhone: true,
  customerEmail: true,
  items: true,
  subtotal: true,
  tax: true,
  discount: true,
  total: true,
  paymentMethod: true,
  notes: true,
});

export const insertBusinessSettingsSchema = createInsertSchema(businessSettings).pick({
  businessName: true,
  address: true,
  phone: true,
  email: true,
  logo: true,
  taxRate: true,
  currency: true,
  receiptFooter: true,
});

export const insertSiteContentSchema = createInsertSchema(siteContent).pick({
  key: true,
  value: true,
  type: true,
});

// Types
export type Receipt = typeof receipts.$inferSelect;
export type InsertReceipt = z.infer<typeof insertReceiptSchema>;

export type BusinessSettings = typeof businessSettings.$inferSelect;
export type InsertBusinessSettings = z.infer<typeof insertBusinessSettingsSchema>;

export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;

export type Article = typeof articles.$inferSelect;
export type InsertArticle = z.infer<typeof insertArticleSchema>;

export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type SiteContent = typeof siteContent.$inferSelect;
export type InsertSiteContent = z.infer<typeof insertSiteContentSchema>;

// Legacy user schema (keeping for compatibility)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
