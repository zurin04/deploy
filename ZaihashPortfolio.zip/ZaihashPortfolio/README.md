# Zaihash Portfolio - One-Click VPS Setup

## Quick Deployment

1. **Upload project** to your VPS
2. **Run setup**:
```bash
sudo ./setup.sh
```

That's it! Your portfolio will be live at your domain.

## What it does
- Installs Node.js, PostgreSQL, PM2, Nginx
- Sets up database with sample content
- Configures domain routing
- Starts the application

## Requirements
- Ubuntu 20.04+ VPS with root access
- Domain pointing to your VPS IP

## After Setup
- Portfolio: http://your-domain.com
- Admin panel: http://your-domain.com/admin
- Check status: `pm2 status`
- View logs: `pm2 logs`

## Optional: Enable HTTPS
```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```