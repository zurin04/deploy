# Zaihash Portfolio & Receipt Pro

One-click deployment for both applications on your VPS.

## Quick Deploy

1. Extract project zip on your VPS
2. Run: `sudo ./setup.sh`
3. Access:
   - Portfolio: http://zaihash.xyz
   - Receipt Pro: http://receipt.zaihash.xyz

## Prerequisites

- Ubuntu 20.04+ VPS with root access
- DNS records: `zaihash.xyz` and `receipt.zaihash.xyz` pointing to your VPS IP

## Management

```bash
pm2 status          # Check applications
pm2 logs            # View logs
pm2 restart all     # Restart both apps
```

## Enable HTTPS

```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d zaihash.xyz -d receipt.zaihash.xyz
```

The setup script automatically installs all dependencies and configures both applications.