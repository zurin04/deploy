# Zaihash Portfolio - VPS Deployment Guide

A futuristic AI-inspired personal portfolio website with wallet-based admin authentication and content management system.

## Features

- **Modern Portfolio Website**: Futuristic dark theme with particle animations
- **Wallet Authentication**: Connect with MetaMask to access admin panel
- **Content Management**: Create and manage blog articles
- **Site Customization**: Update social links and website content
- **VPS Ready**: One-click deployment with Docker

## Quick VPS Deployment

### Prerequisites
- Ubuntu 20.04+ VPS with root access
- Domain configured (zaihash.xyz, admin.zaihash.xyz)
- MetaMask or Web3 wallet

### One-Click Installation

1. **Upload files to your VPS:**
```bash
scp -r . root@your-vps-ip:/opt/zaihash-portfolio/
```

2. **Run the deployment script:**
```bash
ssh root@your-vps-ip
cd /opt/zaihash-portfolio
chmod +x deploy.sh
./deploy.sh
```

3. **Configure DNS:**
   - Point `zaihash.xyz` to your VPS IP
   - Point `admin.zaihash.xyz` to your VPS IP

4. **Setup SSL (Optional but recommended):**
```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d zaihash.xyz -d admin.zaihash.xyz
```

## Admin Access

### Default Admin Wallet
- **Address**: `0x4aa26202ef61c6c7867046afd4ef2cf4c3dc2afd`
- **Access**: Visit `https://admin.zaihash.xyz`
- **Login**: Connect your MetaMask wallet

### Admin Features
- **Articles**: Create, edit, delete blog posts
- **Site Content**: Update social links and website text
- **Publishing**: Control article visibility and featured status

## Manual Setup (Alternative)

### 1. Environment Setup
```bash
cp .env.example .env
# Edit .env with your database URL and settings
```

### 2. Database Setup
```bash
npm install
npm run db:push
```

### 3. Development
```bash
npm run dev
```

### 4. Production Build
```bash
npm run build
npm run start
```

## Architecture

- **Frontend**: React 18 + TypeScript + Tailwind CSS
- **Backend**: Express.js + Drizzle ORM
- **Database**: PostgreSQL
- **Authentication**: Wallet signature verification
- **Deployment**: Docker + Nginx

## API Endpoints

### Public
- `GET /api/articles` - Get published articles
- `GET /api/articles/:slug` - Get article by slug
- `GET /api/site-content` - Get site content

### Admin (Requires wallet authentication)
- `POST /api/admin/auth` - Authenticate with wallet
- `GET /api/admin/articles` - Get all articles
- `POST /api/admin/articles` - Create article
- `PUT /api/admin/articles/:id` - Update article
- `DELETE /api/admin/articles/:id` - Delete article
- `PUT /api/admin/site-content` - Update site content

## Wallet Integration

The admin panel uses Web3 wallet authentication:

1. Connect MetaMask wallet
2. Sign authentication message
3. Server verifies signature against admin wallet address
4. Access granted to authenticated admin

## File Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # UI components
│   │   ├── pages/          # Application pages
│   │   └── lib/           # Utilities
├── server/                 # Express backend
│   ├── db.ts              # Database connection
│   ├── storage.ts         # Data access layer
│   └── routes.ts          # API routes
├── shared/                 # Shared types and schemas
│   └── schema.ts          # Database schema
├── docker-compose.yml      # Container orchestration
├── Dockerfile             # Application container
├── nginx.conf             # Reverse proxy config
└── deploy.sh              # One-click deployment
```

## Customization

### Adding Admin Wallets
Edit the `deploy.sh` script or manually insert into the database:
```sql
INSERT INTO admins (wallet_address, is_active) 
VALUES ('0xYourWalletAddress', true);
```

### Styling
Modify `client/src/index.css` for theme changes and `tailwind.config.ts` for design system updates.

### Content
Use the admin panel at `admin.zaihash.xyz` to manage:
- Blog articles
- Social media links
- About section content
- Contact information

## Support

For deployment issues or customization needs, check the logs:
```bash
docker-compose logs -f
```

## Security Notes

- Only authorized wallet addresses can access admin features
- Use HTTPS in production (included in deployment script)
- Regular database backups recommended
- Keep dependencies updated

## License

MIT License - feel free to customize for your own portfolio.