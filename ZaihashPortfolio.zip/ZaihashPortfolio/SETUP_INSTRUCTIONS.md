# Quick Setup Instructions

## Step 1: Prepare Your VPS

1. Get a VPS running Ubuntu 20.04+
2. Point your domains to the VPS IP:
   - `zaihash.xyz` → Your VPS IP
   - `receipt.zaihash.xyz` → Your VPS IP

## Step 2: Upload Project Files

### Portfolio Files
1. Create a zip of your current portfolio project
2. Upload and extract to `/opt/zaihash-portfolio/` on your VPS

### Receipt Pro Files
1. Download the Receipt Pro project from: https://replit.com/@bryantdayne/PrintReceiptPro
2. Upload and extract to `/opt/receipt-pro/` on your VPS

## Step 3: Run Deployment

```bash
# Download the deployment script
wget https://your-repo/deploy-all.sh

# Make it executable
chmod +x deploy-all.sh

# Run as root
sudo ./deploy-all.sh
```

## Step 4: Access Your Sites

After deployment:
- Portfolio: http://zaihash.xyz
- Receipt Pro: http://receipt.zaihash.xyz

## Step 5: Enable HTTPS (Optional)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d zaihash.xyz -d receipt.zaihash.xyz
```

That's it! Both applications will be running on your VPS with proper domain routing.