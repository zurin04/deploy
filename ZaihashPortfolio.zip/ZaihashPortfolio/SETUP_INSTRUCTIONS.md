# One-Click Setup Instructions

## Quick Setup

1. **Extract** your Replit project zip on your VPS
2. **Run** the setup script:
```bash
sudo ./setup.sh
```

That's it! Everything is automated.

## What It Does
- Installs all dependencies (Node.js, PostgreSQL, PM2, Nginx)
- Sets up databases and users
- Deploys both portfolio and Receipt Pro
- Configures domain routing
- Starts applications

## Prerequisites
- Ubuntu 20.04+ VPS with root access
- DNS: `zaihash.xyz` and `receipt.zaihash.xyz` pointing to your VPS IP

## After Setup
Access your sites:
- Portfolio: http://zaihash.xyz
- Receipt Pro: http://receipt.zaihash.xyz

## Optional: Enable HTTPS
```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d zaihash.xyz -d receipt.zaihash.xyz
```