#!/bin/bash

# VPS deployment script for Receipt Pro at reciept.zaihash.xyz
# Usage: chmod +x deploy-receipt.sh && ./deploy-receipt.sh

set -e

echo "🚀 Starting Receipt Pro deployment for receipt.zaihash.xyz..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Update system
echo "📦 Updating system packages..."
apt update && apt upgrade -y

# Install Node.js and npm
echo "📦 Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install PM2 for process management
npm install -g pm2

# Create application directory for Receipt Pro
echo "📁 Setting up Receipt Pro directory..."
mkdir -p /opt/receipt-pro
cd /opt/receipt-pro

# Copy files if they don't exist (assuming files are already uploaded)
if [ ! -f "package.json" ]; then
    echo "❌ Error: No package.json found. Make sure Receipt Pro files are uploaded to /opt/receipt-pro"
    exit 1
fi

# Install PostgreSQL
echo "🐘 Installing PostgreSQL..."
apt install -y postgresql postgresql-contrib

# Start PostgreSQL service
systemctl start postgresql
systemctl enable postgresql

# Create database and user for Receipt Pro
echo "🔧 Setting up Receipt Pro database..."
sudo -u postgres psql -c "CREATE DATABASE receipt_pro;" 2>/dev/null || echo "Database already exists"
sudo -u postgres psql -c "CREATE USER receiptuser WITH PASSWORD 'securepassword123';" 2>/dev/null || echo "User already exists"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE receipt_pro TO receiptuser;"

# Set up environment variables for Receipt Pro
echo "⚙️ Configuring Receipt Pro environment..."
cat > .env << EOF
NODE_ENV=production
DATABASE_URL=postgresql://receiptuser:securepassword123@localhost:5432/receipt_pro
PORT=3001
EOF

# Install dependencies
echo "📦 Installing Receipt Pro dependencies..."
npm ci --production

# Build the Receipt Pro application
echo "🔨 Building Receipt Pro application..."
npm run build

# Create PM2 ecosystem file for Receipt Pro
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'receipt-pro',
    script: 'dist/index.js',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3001
    }
  }]
};
EOF

# Set up Receipt Pro database schema
echo "🗃️ Setting up Receipt Pro database schema..."
npm run db:push

# Install and configure Nginx
echo "🌐 Installing Nginx..."
apt install -y nginx

# Create Nginx configuration for Receipt Pro subdomain
cat > /etc/nginx/sites-available/receipt-pro << EOF
server {
    listen 80;
    server_name receipt.zaihash.xyz;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

# Enable Receipt Pro site
ln -sf /etc/nginx/sites-available/receipt-pro /etc/nginx/sites-enabled/

# Test Nginx configuration
nginx -t

# Restart Nginx
systemctl restart nginx

# Set file permissions
chown -R $(whoami):$(whoami) /opt/receipt-pro

# Start Receipt Pro with PM2
echo "🚀 Starting Receipt Pro application..."
pm2 delete receipt-pro 2>/dev/null || true
pm2 start ecosystem.config.js
pm2 save
pm2 startup

echo "✅ Receipt Pro deployment successful!"
echo ""
echo "🌐 Your Receipt Pro application is now accessible at:"
echo "   http://receipt.zaihash.xyz"
echo ""
echo "🔧 To manage Receipt Pro:"
echo "   View logs: pm2 logs receipt-pro"
echo "   Restart: pm2 restart receipt-pro"
echo "   Stop: pm2 stop receipt-pro"
echo "   Status: pm2 status"
echo ""
echo "⚠️  To enable HTTPS for Receipt Pro:"
echo "   apt install certbot python3-certbot-nginx"
echo "   certbot --nginx -d receipt.zaihash.xyz"
echo ""
echo "📋 Receipt Pro features:"
echo "   - Professional receipt generation"
echo "   - PDF export and printing"
echo "   - Business settings configuration"
echo "   - Receipt history and management"
echo "   - Revenue tracking dashboard"