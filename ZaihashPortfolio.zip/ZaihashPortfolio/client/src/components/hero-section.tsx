import { Rocket, User } from "lucide-react";
import ParticlesBackground from "./particles-background";
import { motion } from "framer-motion";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offsetTop = element.offsetTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <ParticlesBackground />
      
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="animate-slideInUp"
        >
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black mb-6">
            <span className="text-gradient">Zaihash</span>
          </h1>
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-light mb-8 text-[var(--steel-gray)]">
            Builder of the <span className="text-[var(--electric-purple)] font-semibold">Future</span>
          </h2>
          <p className="text-lg sm:text-xl max-w-3xl mx-auto mb-12 text-[var(--steel-gray)] leading-relaxed">
            From humble beginnings to crafting the next generation of tech solutions. 
            <span className="text-[var(--neon-green)]"> AI</span>, <span className="text-[var(--electric-purple)]"> Web3</span>, 
            and pure innovation driving the vision to uplift through technology.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button 
              onClick={() => scrollToSection('projects')}
              className="btn-glow px-8 py-4 rounded-full text-lg font-semibold hover:text-white transition-all duration-300 flex items-center gap-2"
            >
              <Rocket size={20} />
              Explore Projects
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="px-8 py-4 rounded-full text-lg font-semibold border border-[var(--electric-purple)]/50 hover:border-[var(--electric-purple)] hover:bg-[var(--electric-purple)]/10 transition-all duration-300 flex items-center gap-2"
            >
              <User size={20} />
              My Story
            </button>
          </div>
        </motion.div>
      </div>

      {/* Floating Elements */}
      <div className="absolute top-1/4 left-10 animate-float">
        <div className="w-4 h-4 bg-[var(--neon-green)] rounded-full animate-glow"></div>
      </div>
      <div className="absolute top-1/3 right-16 animate-float" style={{animationDelay: '2s'}}>
        <div className="w-3 h-3 bg-[var(--electric-purple)] rounded-full animate-glow"></div>
      </div>
      <div className="absolute bottom-1/3 left-1/4 animate-float" style={{animationDelay: '4s'}}>
        <div className="w-5 h-5 bg-[var(--neon-green)]/50 rounded-full animate-glow"></div>
      </div>
    </section>
  );
}
