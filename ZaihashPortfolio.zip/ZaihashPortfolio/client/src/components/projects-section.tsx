import { ExternalLink, Github, Coins, TrendingUp, Wifi, Bot, Store, PieChart, Code, Smartphone, Globe } from "lucide-react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import type { Project } from "@shared/schema";

// Category icon mapping
const categoryIcons: Record<string, any> = {
  webapp: Globe,
  mobile: Smartphone,
  ai: Bot,
  blockchain: Coins,
  web3: Store,
  fintech: TrendingUp,
  iot: Wifi,
  analytics: PieChart,
  default: Code
};

// Category color mapping
const categoryColors: Record<string, string> = {
  webapp: "text-[var(--electric-purple)]",
  mobile: "text-[var(--neon-green)]", 
  ai: "text-[var(--electric-purple)]",
  blockchain: "text-[var(--neon-green)]",
  web3: "text-[var(--neon-green)]",
  fintech: "text-[var(--electric-purple)]",
  iot: "text-[var(--neon-green)]",
  analytics: "text-[var(--electric-purple)]",
  default: "text-[var(--steel-gray)]"
};

export default function ProjectsSection() {
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const response = await fetch("/api/projects");
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
  });

  const { data: featuredProjects = [] } = useQuery({
    queryKey: ["projects", "featured"],
    queryFn: async () => {
      const response = await fetch("/api/projects/featured");
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
  });

  // Show featured projects if available, otherwise show all published projects
  const displayProjects = (Array.isArray(featuredProjects) && featuredProjects.length > 0) ? featuredProjects : projects;

  if (isLoading) {
    return (
      <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">Projects</h2>
            <p className="text-xl text-[var(--steel-gray)]">Raw execution, vision, and innovation in action</p>
          </div>
          <div className="text-center text-[var(--steel-gray)]">Loading projects...</div>
        </div>
      </section>
    );
  }

  if (displayProjects.length === 0) {
    return (
      <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">Projects</h2>
            <p className="text-xl text-[var(--steel-gray)]">Raw execution, vision, and innovation in action</p>
          </div>
          <div className="text-center text-[var(--steel-gray)]">No projects published yet. Check back soon!</div>
        </div>
      </section>
    );
  }

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">Projects</h2>
          <p className="text-xl text-[var(--steel-gray)]">Raw execution, vision, and innovation in action</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayProjects.map((project: Project, index: number) => {
            const IconComponent = categoryIcons[project.category.toLowerCase()] || categoryIcons.default;
            const categoryColor = categoryColors[project.category.toLowerCase()] || categoryColors.default;
            
            return (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="project-card glow-border rounded-2xl p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-[var(--neon-green)] to-[var(--electric-purple)] rounded-lg flex items-center justify-center">
                    <IconComponent className="text-xl text-white" size={24} />
                  </div>
                  <span className={`text-sm ${categoryColor} font-semibold capitalize`}>
                    {project.category}
                  </span>
                </div>
                
                <h3 className="text-xl font-bold mb-3 text-white">{project.title}</h3>
                <p className="text-[var(--steel-gray)] mb-6 text-sm leading-relaxed">
                  {project.shortDescription || project.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.technologies?.map((tech) => (
                    <span 
                      key={tech}
                      className="text-xs bg-[var(--electric-purple)]/20 text-[var(--electric-purple)] px-2 py-1 rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                
                <div className="flex gap-3">
                  {project.liveUrl && (
                    <a 
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 bg-gradient-to-r from-[var(--neon-green)]/20 to-[var(--electric-purple)]/20 border border-[var(--neon-green)]/30 text-[var(--neon-green)] text-center py-2 rounded-lg hover:from-[var(--neon-green)]/30 hover:to-[var(--electric-purple)]/30 transition-all duration-300 text-sm flex items-center justify-center gap-1"
                    >
                      <ExternalLink size={16} />
                      Live Demo
                    </a>
                  )}
                  {project.githubUrl && (
                    <a 
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 border border-[var(--steel-gray)]/30 text-[var(--steel-gray)] rounded-lg hover:border-[var(--steel-gray)] hover:text-white transition-all duration-300 flex items-center justify-center"
                    >
                      <Github size={16} />
                    </a>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
