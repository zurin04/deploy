import { Calendar, Clock, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import type { Article } from "@shared/schema";

export default function ArticlesSection() {
  const { data: articles = [], isLoading } = useQuery({
    queryKey: ["articles"],
    queryFn: async () => {
      const response = await fetch("/api/articles");
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
  });

  if (isLoading) {
    return (
      <section id="articles" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">Latest Articles</h2>
            <p className="text-xl text-[var(--steel-gray)]">Insights, thoughts, and technical deep-dives</p>
          </div>
          <div className="text-center text-[var(--steel-gray)]">Loading articles...</div>
        </div>
      </section>
    );
  }

  if (articles.length === 0) {
    return null; // Don't show the section if no articles
  }

  const formatDate = (dateValue: any) => {
    if (!dateValue) return 'Recently';
    const date = typeof dateValue === 'string' ? new Date(dateValue) : dateValue;
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <section id="articles" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">Latest Articles</h2>
          <p className="text-xl text-[var(--steel-gray)]">Insights, thoughts, and technical deep-dives</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articles.map((article: Article, index: number) => (
            <motion.article
              key={article.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="article-card glow-border rounded-2xl p-6 hover:scale-105 transition-transform duration-300"
            >
              <div className="flex items-center gap-2 mb-4 text-sm text-[var(--steel-gray)]">
                <Calendar size={16} />
                <span>{formatDate(article.createdAt)}</span>
                {article.featured && (
                  <span className="ml-2 bg-gradient-to-r from-[var(--neon-green)] to-[var(--electric-purple)] text-white text-xs px-2 py-1 rounded-full">
                    Featured
                  </span>
                )}
              </div>
              
              <h3 className="text-xl font-bold mb-3 text-white hover:text-gradient transition-colors">
                {article.title}
              </h3>
              
              <p className="text-[var(--steel-gray)] mb-6 text-sm leading-relaxed line-clamp-3">
                {article.excerpt}
              </p>
              
              {article.tags && article.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-6">
                  {article.tags.map((tag) => (
                    <span 
                      key={tag}
                      className="text-xs bg-[var(--electric-purple)]/20 text-[var(--electric-purple)] px-2 py-1 rounded-full"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-xs text-[var(--steel-gray)]">
                  <Clock size={14} />
                  <span>5 min read</span>
                </div>
                
                <a 
                  href={`/articles/${article.slug}`}
                  className="inline-flex items-center gap-1 text-sm text-[var(--neon-green)] hover:text-white transition-colors"
                >
                  Read More
                  <ExternalLink size={14} />
                </a>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}