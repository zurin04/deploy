import { motion } from "framer-motion";

export default function AboutSection() {
  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">The Journey</h2>
          <p className="text-xl text-[var(--steel-gray)]">From poverty to building the future</p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="glow-border rounded-2xl p-8 bg-[var(--charcoal)]/30 backdrop-blur-sm"
            >
              <h3 className="text-2xl font-bold mb-4 text-[var(--neon-green)]">The Beginning</h3>
              <p className="text-[var(--steel-gray)] leading-relaxed">
                Started from the bottom with nothing but a vision and unwavering determination. 
                Every line of code written was a step towards breaking generational barriers and 
                creating something meaningful for my family's future.
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="glow-border rounded-2xl p-8 bg-[var(--charcoal)]/30 backdrop-blur-sm"
            >
              <h3 className="text-2xl font-bold mb-4 text-[var(--electric-purple)]">The Vision</h3>
              <p className="text-[var(--steel-gray)] leading-relaxed">
                Building isn't just about creating apps—it's about crafting solutions that empower others. 
                Through AI, Web3, and cutting-edge technology, I'm creating tools that democratize access 
                to financial freedom and technological innovation.
              </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="glow-border rounded-2xl p-8 bg-[var(--charcoal)]/30 backdrop-blur-sm"
            >
              <h3 className="text-2xl font-bold mb-4 text-[var(--neon-green)]">The Mission</h3>
              <p className="text-[var(--steel-gray)] leading-relaxed">
                Every project is a testament to what's possible when determination meets opportunity. 
                I'm not just building for today—I'm laying the foundation for a future where technology 
                serves humanity and lifts communities.
              </p>
            </motion.div>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <img 
              src="https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Modern developer workspace" 
              className="rounded-2xl shadow-2xl glow-border w-full"
            />
            
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-r from-[var(--neon-green)] to-[var(--electric-purple)] rounded-full animate-glow opacity-20"></div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-to-r from-[var(--electric-purple)] to-[var(--neon-green)] rounded-full animate-glow opacity-30"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
