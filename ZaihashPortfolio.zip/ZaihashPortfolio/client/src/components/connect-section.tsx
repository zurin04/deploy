import { Twitter, Github, Mail, Rocket } from "lucide-react";
import { motion } from "framer-motion";

const socialLinks = [
  {
    name: "Twitter",
    description: "Follow the journey and latest updates",
    icon: Twitter,
    url: "https://twitter.com/zaihash",
    color: "from-blue-400 to-blue-600"
  },
  {
    name: "GitHub",
    description: "Explore the code and contribute",
    icon: Github,
    url: "https://github.com/zaihash",
    color: "from-gray-700 to-gray-900"
  },
  {
    name: "Email",
    description: "Get in touch for collaborations",
    icon: Mail,
    url: "mailto:hello@zaihash.dev",
    color: "from-[var(--neon-green)] to-[var(--electric-purple)]"
  }
];

export default function ConnectSection() {
  return (
    <section id="connect" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto text-center">
        <div className="mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">Let's Build Together</h2>
          <p className="text-xl text-[var(--steel-gray)]">Ready to create something extraordinary? Let's connect.</p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {socialLinks.map((link, index) => (
            <motion.a
              key={link.name}
              href={link.url}
              target={link.url.startsWith('http') ? '_blank' : undefined}
              rel={link.url.startsWith('http') ? 'noopener noreferrer' : undefined}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group glow-border rounded-2xl p-8 bg-[var(--charcoal)]/30 backdrop-blur-sm hover:bg-[var(--charcoal)]/50 transition-all duration-300 block"
            >
              <div className={`w-16 h-16 bg-gradient-to-r ${link.color} rounded-2xl mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                <link.icon className="text-2xl text-white" size={24} />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{link.name}</h3>
              <p className="text-[var(--steel-gray)] text-sm">{link.description}</p>
            </motion.a>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="glow-border rounded-2xl p-8 bg-gradient-to-r from-[var(--charcoal)]/50 to-[var(--space-blue)]/50 backdrop-blur-sm"
        >
          <h3 className="text-2xl font-bold mb-4 text-white">Ready to Innovate?</h3>
          <p className="text-[var(--steel-gray)] mb-6 max-w-2xl mx-auto">
            Whether you're looking to build the next breakthrough application, explore AI solutions, 
            or dive into Web3 technologies, let's turn your vision into reality.
          </p>
          <a 
            href="mailto:hello@zaihash.dev" 
            className="btn-glow px-8 py-4 rounded-full text-lg font-semibold inline-flex items-center hover:text-white transition-all duration-300 gap-2"
          >
            <Rocket size={20} />
            Start Building
          </a>
        </motion.div>
      </div>
    </section>
  );
}
