import { Code, Cpu, Database, Container, Brain, Blocks } from "lucide-react";
import { SiReact, SiNodedotjs, SiPython, SiSolidity, SiMongodb, SiDocker, SiTensorflow } from "react-icons/si";
import { motion } from "framer-motion";

const technologies = [
  { name: "React", category: "Frontend Framework", icon: SiReact, color: "text-[var(--neon-green)]" },
  { name: "Node.js", category: "Backend Runtime", icon: SiNodedotjs, color: "text-[var(--electric-purple)]" },
  { name: "Python", category: "AI & Analytics", icon: SiPython, color: "text-[var(--neon-green)]" },
  { name: "Solidity", category: "Smart Contracts", icon: SiSolidity, color: "text-[var(--electric-purple)]" },
  { name: "ESP32", category: "IoT Hardware", icon: Cpu, color: "text-[var(--neon-green)]" },
  { name: "MongoDB", category: "Database", icon: SiMongodb, color: "text-[var(--electric-purple)]" },
  { name: "Docker", category: "Containerization", icon: SiDocker, color: "text-[var(--neon-green)]" },
  { name: "TensorFlow", category: "Machine Learning", icon: SiTensorflow, color: "text-[var(--electric-purple)]" }
];

const skillCategories = [
  {
    title: "Full-Stack Development",
    description: "End-to-end application development with modern frameworks and best practices",
    icon: Code,
    color: "text-[var(--neon-green)]"
  },
  {
    title: "Blockchain & Web3",
    description: "Decentralized applications, smart contracts, and cryptocurrency integration",
    icon: Blocks,
    color: "text-[var(--electric-purple)]"
  },
  {
    title: "AI & Machine Learning",
    description: "Intelligent systems, predictive analytics, and automated decision-making",
    icon: Brain,
    color: "text-[var(--neon-green)]"
  }
];

export default function TechStackSection() {
  return (
    <section id="tech" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">Tech Arsenal</h2>
          <p className="text-xl text-[var(--steel-gray)]">Tools and technologies powering the vision</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 mb-16">
          {technologies.map((tech, index) => (
            <motion.div
              key={tech.name}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center group"
            >
              <div className="tech-icon w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-[var(--neon-green)]/20 to-[var(--electric-purple)]/20 rounded-2xl flex items-center justify-center glow-border">
                <tech.icon className={`text-3xl ${tech.color}`} />
              </div>
              <h3 className={`font-semibold text-white group-hover:${tech.color} transition-colors duration-300`}>
                {tech.name}
              </h3>
              <p className="text-sm text-[var(--steel-gray)]">{tech.category}</p>
            </motion.div>
          ))}
        </div>

        {/* Skills Categories */}
        <div className="grid md:grid-cols-3 gap-8">
          {skillCategories.map((skill, index) => (
            <motion.div
              key={skill.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="glow-border rounded-2xl p-6 bg-[var(--charcoal)]/30 backdrop-blur-sm text-center"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-[var(--neon-green)] to-[var(--electric-purple)] rounded-full mx-auto mb-4 flex items-center justify-center">
                <skill.icon className="text-xl text-white" size={24} />
              </div>
              <h3 className={`text-xl font-bold mb-3 ${skill.color}`}>{skill.title}</h3>
              <p className="text-[var(--steel-gray)] text-sm">{skill.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
