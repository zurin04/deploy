import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Save, Building } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function BusinessSettingsForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: businessSettings } = useQuery({
    queryKey: ['/api/business-settings'],
  });

  const [formData, setFormData] = useState({
    businessName: businessSettings?.businessName || "",
    address: businessSettings?.address || "",
    phone: businessSettings?.phone || "",
    email: businessSettings?.email || "",
    logo: businessSettings?.logo || "",
    taxRate: businessSettings?.taxRate || "0",
    currency: businessSettings?.currency || "USD",
    receiptFooter: businessSettings?.receiptFooter || "Thank you for your business!",
  });

  // Update form when data loads
  React.useEffect(() => {
    if (businessSettings) {
      setFormData({
        businessName: businessSettings.businessName || "",
        address: businessSettings.address || "",
        phone: businessSettings.phone || "",
        email: businessSettings.email || "",
        logo: businessSettings.logo || "",
        taxRate: businessSettings.taxRate || "8.25",
        currency: businessSettings.currency || "USD",
        receiptFooter: businessSettings.receiptFooter || "Thank you for your business!",
      });
    }
  }, [businessSettings]);

  const updateSettingsMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest('/api/business-settings', {
        method: 'PUT',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({ title: "Business settings updated successfully!" });
      queryClient.invalidateQueries({ queryKey: ['/api/business-settings'] });
    },
    onError: () => {
      toast({ title: "Failed to update business settings", variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettingsMutation.mutate(formData);
  };

  const handleChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="businessName">Business Name *</Label>
          <Input
            id="businessName"
            value={formData.businessName}
            onChange={(e) => handleChange('businessName', e.target.value)}
            placeholder="Your Business Name"
            required
          />
        </div>

        <div>
          <Label htmlFor="phone">Phone Number</Label>
          <Input
            id="phone"
            value={formData.phone}
            onChange={(e) => handleChange('phone', e.target.value)}
            placeholder="+1 (555) 123-4567"
          />
        </div>

        <div>
          <Label htmlFor="email">Email Address</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => handleChange('email', e.target.value)}
            placeholder="contact@yourbusiness.com"
          />
        </div>

        <div>
          <Label htmlFor="currency">Currency</Label>
          <Input
            id="currency"
            value={formData.currency}
            onChange={(e) => handleChange('currency', e.target.value)}
            placeholder="USD"
          />
        </div>

        <div>
          <Label htmlFor="taxRate">Tax Rate (%)</Label>
          <Input
            id="taxRate"
            type="number"
            step="0.01"
            value={formData.taxRate}
            onChange={(e) => handleChange('taxRate', e.target.value)}
            placeholder="8.25"
          />
        </div>

        <div>
          <Label htmlFor="logo">Logo URL</Label>
          <Input
            id="logo"
            value={formData.logo}
            onChange={(e) => handleChange('logo', e.target.value)}
            placeholder="https://example.com/logo.png"
          />
        </div>
      </div>

      <div>
        <Label htmlFor="address">Business Address</Label>
        <Textarea
          id="address"
          value={formData.address}
          onChange={(e) => handleChange('address', e.target.value)}
          placeholder="123 Main Street, City, State 12345"
          rows={3}
        />
      </div>

      <div>
        <Label htmlFor="receiptFooter">Receipt Footer Message</Label>
        <Textarea
          id="receiptFooter"
          value={formData.receiptFooter}
          onChange={(e) => handleChange('receiptFooter', e.target.value)}
          placeholder="Thank you for your business! Visit us again soon."
          rows={2}
        />
      </div>

      <Button 
        type="submit" 
        disabled={updateSettingsMutation.isPending}
        className="w-full"
      >
        <Save className="h-4 w-4 mr-2" />
        {updateSettingsMutation.isPending ? "Saving..." : "Save Business Settings"}
      </Button>
    </form>
  );
}