import { useState, useEffect } from "react";
import { ethers } from "ethers";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Wallet, LogOut, Shield, CheckCircle, AlertCircle, ExternalLink, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

interface WalletConnectProps {
  onAuthenticated: (walletAddress: string) => void;
  onDisconnect: () => void;
  isAuthenticated: boolean;
  walletAddress?: string;
}

export default function WalletConnect({ 
  onAuthenticated, 
  onDisconnect, 
  isAuthenticated, 
  walletAddress 
}: WalletConnectProps) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [walletInfo, setWalletInfo] = useState<{
    balance?: string;
    network?: string;
    ens?: string;
  }>({});
  const { toast } = useToast();

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  const getWalletInfo = async (address: string) => {
    try {
      const provider = new ethers.BrowserProvider((window as any).ethereum);
      const balance = await provider.getBalance(address);
      const network = await provider.getNetwork();
      
      // Try to get ENS name
      let ensName;
      try {
        ensName = await provider.lookupAddress(address);
      } catch (e) {
        // ENS lookup failed, continue without it
      }

      setWalletInfo({
        balance: ethers.formatEther(balance),
        network: network.name,
        ens: ensName || undefined
      });
    } catch (error) {
      console.log("Failed to get wallet info:", error);
    }
  };

  useEffect(() => {
    if (isAuthenticated && walletAddress) {
      getWalletInfo(walletAddress);
    }
  }, [isAuthenticated, walletAddress]);

  const connectWallet = async () => {
    if (!(window as any).ethereum) {
      toast({
        title: "Wallet not found",
        description: "Please install MetaMask or another Web3 wallet",
        variant: "destructive",
      });
      return;
    }

    setIsConnecting(true);

    try {
      const provider = new ethers.BrowserProvider((window as any).ethereum);
      
      // Request account access
      await provider.send("eth_requestAccounts", []);
      const signer = await provider.getSigner();
      const address = await signer.getAddress();

      // Create message to sign
      const message = `Admin login to Zaihash Portfolio\nTimestamp: ${Date.now()}`;
      
      // Sign the message
      const signature = await signer.signMessage(message);

      // Send to backend for verification
      const response = await fetch("/api/admin/auth", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          walletAddress: address,
          signature,
          message,
        }),
      });

      const data = await response.json();

      if (data.success) {
        onAuthenticated(address);
        toast({
          title: "Successfully connected",
          description: "You are now authenticated as admin",
        });
      } else {
        toast({
          title: "Authentication failed",
          description: data.error || "Invalid wallet address",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error("Wallet connection error:", error);
      toast({
        title: "Connection failed",
        description: error.message || "Failed to connect wallet",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnect = () => {
    onDisconnect();
    toast({
      title: "Disconnected",
      description: "You have been logged out",
    });
  };

  if (isAuthenticated && walletAddress) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <Card className="bg-gradient-to-br from-[var(--space-blue)] to-[var(--dark-gray)] border-[var(--electric-purple)]/30">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-[var(--neon-green)]" />
                <CardTitle className="text-lg text-white">Wallet Connected</CardTitle>
              </div>
              <Badge variant="secondary" className="bg-[var(--neon-green)]/20 text-[var(--neon-green)]">
                <Shield className="w-3 h-3 mr-1" />
                Admin
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-[var(--steel-gray)]">Address:</span>
                <div className="flex items-center gap-2">
                  <code className="text-sm bg-[var(--dark-gray)] px-2 py-1 rounded text-white">
                    {walletAddress.slice(0, 6)}...{walletAddress.slice(-4)}
                  </code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(walletAddress)}
                    className="h-7 w-7 p-0 hover:bg-[var(--electric-purple)]/20"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>

              {walletInfo.ens && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[var(--steel-gray)]">ENS:</span>
                  <span className="text-sm text-[var(--neon-green)]">{walletInfo.ens}</span>
                </div>
              )}

              {walletInfo.network && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[var(--steel-gray)]">Network:</span>
                  <Badge variant="outline" className="text-xs capitalize">
                    {walletInfo.network}
                  </Badge>
                </div>
              )}

              {walletInfo.balance && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-[var(--steel-gray)]">Balance:</span>
                  <span className="text-sm text-white">
                    {parseFloat(walletInfo.balance).toFixed(4)} ETH
                  </span>
                </div>
              )}
            </div>

            <Separator className="bg-[var(--steel-gray)]/30" />

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(`https://etherscan.io/address/${walletAddress}`, '_blank')}
                className="flex-1 border-[var(--electric-purple)]/30 hover:bg-[var(--electric-purple)]/20"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                View on Etherscan
              </Button>
              
              <Button 
                variant="destructive" 
                size="sm" 
                onClick={disconnect}
                className="bg-red-600/20 hover:bg-red-600/30 border-red-500/30"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Disconnect
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full max-w-md"
    >
      <Card className="bg-gradient-to-br from-[var(--space-blue)] to-[var(--dark-gray)] border-[var(--electric-purple)]/30">
        <CardHeader className="text-center">
          <motion.div
            animate={{ 
              rotate: isConnecting ? 360 : 0,
              scale: isConnecting ? 1.1 : 1 
            }}
            transition={{ 
              rotate: { duration: 2, repeat: isConnecting ? Infinity : 0, ease: "linear" },
              scale: { duration: 0.3 }
            }}
            className="mx-auto mb-4 w-16 h-16 rounded-full bg-gradient-to-r from-[var(--neon-green)] to-[var(--electric-purple)] flex items-center justify-center"
          >
            <Shield className="w-8 h-8 text-white" />
          </motion.div>
          
          <CardTitle className="text-2xl text-white mb-2">
            Admin Access Required
          </CardTitle>
          <CardDescription className="text-[var(--steel-gray)]">
            Connect your authorized wallet to access the admin panel
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="bg-[var(--dark-gray)]/50 rounded-lg p-4 border border-[var(--steel-gray)]/20">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-[var(--electric-purple)] mt-0.5 flex-shrink-0" />
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-white">Security Notice</h4>
                <p className="text-xs text-[var(--steel-gray)] leading-relaxed">
                  Only the authorized admin wallet can access this panel. You'll be asked to sign a message to verify ownership.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-[var(--steel-gray)]">
              <CheckCircle className="w-4 h-4 text-[var(--neon-green)]" />
              Secure wallet authentication
            </div>
            <div className="flex items-center gap-2 text-sm text-[var(--steel-gray)]">
              <CheckCircle className="w-4 h-4 text-[var(--neon-green)]" />
              No passwords required
            </div>
            <div className="flex items-center gap-2 text-sm text-[var(--steel-gray)]">
              <CheckCircle className="w-4 h-4 text-[var(--neon-green)]" />
              Full content management access
            </div>
          </div>

          <Button 
            onClick={connectWallet} 
            disabled={isConnecting}
            className="w-full bg-gradient-to-r from-[var(--neon-green)] to-[var(--electric-purple)] hover:from-[var(--neon-green)]/80 hover:to-[var(--electric-purple)]/80 text-white font-medium py-3 text-base"
          >
            <Wallet className="w-5 h-5 mr-3" />
            {isConnecting ? (
              <span className="flex items-center gap-2">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="w-4 h-4 border-2 border-white border-t-transparent rounded-full"
                />
                Connecting Wallet...
              </span>
            ) : (
              "Connect Wallet to Continue"
            )}
          </Button>

          <div className="text-center">
            <p className="text-xs text-[var(--steel-gray)]">
              Don't have MetaMask?{" "}
              <a 
                href="https://metamask.io" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[var(--electric-purple)] hover:text-[var(--neon-green)] transition-colors"
              >
                Install here
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}