export default function Footer() {
  return (
    <footer className="py-8 px-4 sm:px-6 lg:px-8 border-t border-[var(--electric-purple)]/20">
      <div className="max-w-6xl mx-auto text-center">
        <div className="flex justify-center items-center mb-4">
          <div className="text-2xl font-bold text-gradient">Zaihash</div>
        </div>
        <p className="text-[var(--steel-gray)] text-sm">
          © 2024 Zaihash. Built with passion, powered by innovation.
        </p>
        <p className="text-[var(--steel-gray)] text-xs mt-2">
          Crafting the future, one line of code at a time.
        </p>
      </div>
    </footer>
  );
}
