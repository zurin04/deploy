import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Eye, Trash2, Download, Plus } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import type { Receipt } from "@shared/schema";

export default function Receipts() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");

  const { data: receipts = [], isLoading } = useQuery({
    queryKey: ['/api/receipts'],
  });

  const deleteReceiptMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest(`/api/receipts/${id}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      toast({ title: "Receipt deleted successfully" });
      queryClient.invalidateQueries({ queryKey: ['/api/receipts'] });
    },
    onError: () => {
      toast({ title: "Failed to delete receipt", variant: "destructive" });
    },
  });

  const filteredReceipts = receipts.filter((receipt: Receipt) =>
    receipt.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    receipt.customerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    receipt.businessName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this receipt?")) {
      deleteReceiptMutation.mutate(id);
    }
  };

  const handleDownload = (receipt: Receipt) => {
    // Generate PDF download
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      const items = Array.isArray(receipt.items) ? receipt.items : [];
      printWindow.document.write(`
        <html>
          <head>
            <title>Receipt ${receipt.receiptNumber}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              .receipt { max-width: 400px; margin: 0 auto; }
              .header { text-align: center; margin-bottom: 20px; }
              .business-name { font-size: 18px; font-weight: bold; }
              .section { margin: 15px 0; }
              .items-table { width: 100%; border-collapse: collapse; }
              .items-table th, .items-table td { padding: 5px; text-align: left; border-bottom: 1px solid #ddd; }
              .totals { text-align: right; margin-top: 15px; }
              .total-line { font-weight: bold; font-size: 16px; }
            </style>
          </head>
          <body>
            <div class="receipt">
              <div class="header">
                <div class="business-name">${receipt.businessName}</div>
                ${receipt.businessAddress ? `<div>${receipt.businessAddress}</div>` : ''}
                ${receipt.businessPhone ? `<div>Tel: ${receipt.businessPhone}</div>` : ''}
              </div>
              <hr>
              <div class="section">
                <div>Receipt: ${receipt.receiptNumber}</div>
                <div>Date: ${new Date(receipt.createdAt).toLocaleDateString()}</div>
                ${receipt.customerName ? `<div>Customer: ${receipt.customerName}</div>` : ''}
              </div>
              <hr>
              <table class="items-table">
                <thead>
                  <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                  ${items.map((item: any) => `
                    <tr>
                      <td>${item.name}</td>
                      <td>${item.quantity}</td>
                      <td>$${item.price.toFixed(2)}</td>
                      <td>$${item.total.toFixed(2)}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
              <hr>
              <div class="totals">
                <div>Subtotal: $${receipt.subtotal}</div>
                <div>Tax: $${receipt.tax}</div>
                <div class="total-line">Total: $${receipt.total}</div>
                <div>Payment: ${receipt.paymentMethod}</div>
              </div>
              ${receipt.notes ? `<div class="section"><strong>Notes:</strong> ${receipt.notes}</div>` : ''}
              <hr>
              <div style="text-align: center; font-size: 12px;">Thank you for your business!</div>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Receipt History</h1>
        <Link href="/receipt-generator">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Receipt
          </Button>
        </Link>
      </div>

      {/* Search */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search receipts by number, customer, or business name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Receipts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredReceipts.map((receipt: Receipt) => {
          const items = Array.isArray(receipt.items) ? receipt.items : [];
          const itemCount = items.length;
          
          return (
            <Card key={receipt.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{receipt.receiptNumber}</CardTitle>
                    <p className="text-sm text-gray-600">{receipt.businessName}</p>
                  </div>
                  <Badge variant="secondary">
                    ${receipt.total}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Customer:</span>
                    <span>{receipt.customerName || "Walk-in"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Items:</span>
                    <span>{itemCount} item{itemCount !== 1 ? 's' : ''}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Payment:</span>
                    <span>{receipt.paymentMethod}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Date:</span>
                    <span>{new Date(receipt.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDownload(receipt)}
                    className="flex-1"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    PDF
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(receipt.id)}
                    disabled={deleteReceiptMutation.isPending}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredReceipts.length === 0 && (
        <div className="text-center py-12">
          <div className="text-gray-500 mb-4">
            {searchTerm ? "No receipts found matching your search." : "No receipts created yet."}
          </div>
          <Link href="/receipt-generator">
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Receipt
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}