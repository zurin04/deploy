import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import WalletConnect from "@/components/wallet-connect";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { PlusIcon, EditIcon, TrashIcon, SaveIcon, SearchIcon, FilterIcon, BarChart3Icon, UsersIcon, TrendingUpIcon, EyeIcon, ExternalLinkIcon } from "lucide-react";
import type { Article, Project, SiteContent } from "@shared/schema";

interface AdminState {
  isAuthenticated: boolean;
  walletAddress?: string;
}

export default function Admin() {
  const [adminState, setAdminState] = useState<AdminState>({
    isAuthenticated: false
  });
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [newArticle, setNewArticle] = useState({
    title: "",
    slug: "",
    content: "",
    excerpt: "",
    featured: false,
    published: false,
    tags: [] as string[],
  });
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [newProject, setNewProject] = useState({
    title: "",
    description: "",
    shortDescription: "",
    imageUrl: "",
    liveUrl: "",
    githubUrl: "",
    technologies: [] as string[],
    category: "",
    featured: false,
    published: false,
    orderIndex: 0,
  });
  const [siteContentEdits, setSiteContentEdits] = useState<Record<string, string>>({});
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "published" | "draft">("all");
  const [activeTab, setActiveTab] = useState("dashboard");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Queries
  const { data: articles = [], isLoading: articlesLoading } = useQuery({
    queryKey: ["admin", "articles"],
    queryFn: async () => {
      const response = await fetch("/api/admin/articles", {
        headers: { walletAddress: adminState.walletAddress || "" }
      });
      if (!response.ok) {
        throw new Error("Failed to fetch articles");
      }
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
    enabled: adminState.isAuthenticated && !!adminState.walletAddress,
  });

  const { data: projects = [], isLoading: projectsLoading } = useQuery({
    queryKey: ["admin", "projects"],
    queryFn: async () => {
      const response = await fetch("/api/admin/projects", {
        headers: { walletAddress: adminState.walletAddress || "" }
      });
      if (!response.ok) {
        throw new Error("Failed to fetch projects");
      }
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
    enabled: adminState.isAuthenticated && !!adminState.walletAddress,
  });

  const { data: siteContent = [], isLoading: siteContentLoading } = useQuery({
    queryKey: ["admin", "site-content"],
    queryFn: () => fetch("/api/site-content").then(res => res.json()),
    enabled: adminState.isAuthenticated,
  });

  // Mutations
  const createArticleMutation = useMutation({
    mutationFn: async (data: typeof newArticle) => {
      const response = await fetch("/api/admin/articles", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { 
          "Content-Type": "application/json",
          walletAddress: adminState.walletAddress || "" 
        }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "articles"] });
      setNewArticle({
        title: "",
        slug: "",
        content: "",
        excerpt: "",
        featured: false,
        published: false,
        tags: [],
      });
      toast({ title: "Article created successfully" });
    },
  });

  const updateArticleMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Article> }) => {
      const response = await fetch(`/api/admin/articles/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: { 
          "Content-Type": "application/json",
          walletAddress: adminState.walletAddress || "" 
        }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "articles"] });
      setEditingArticle(null);
      toast({ title: "Article updated successfully" });
    },
  });

  const deleteArticleMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/admin/articles/${id}`, {
        method: "DELETE",
        headers: { walletAddress: adminState.walletAddress || "" }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "articles"] });
      toast({ title: "Article deleted successfully" });
    },
  });

  const createProjectMutation = useMutation({
    mutationFn: async (data: typeof newProject) => {
      const response = await fetch("/api/admin/projects", {
        method: "POST",
        body: JSON.stringify(data),
        headers: { 
          "Content-Type": "application/json",
          walletAddress: adminState.walletAddress || "" 
        }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "projects"] });
      setNewProject({
        title: "",
        description: "",
        shortDescription: "",
        imageUrl: "",
        liveUrl: "",
        githubUrl: "",
        technologies: [],
        category: "",
        featured: false,
        published: false,
        orderIndex: 0,
      });
      toast({ title: "Project created successfully" });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Project> }) => {
      const response = await fetch(`/api/admin/projects/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
        headers: { 
          "Content-Type": "application/json",
          walletAddress: adminState.walletAddress || "" 
        }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "projects"] });
      setEditingProject(null);
      toast({ title: "Project updated successfully" });
    },
  });

  const deleteProjectMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/admin/projects/${id}`, {
        method: "DELETE",
        headers: { walletAddress: adminState.walletAddress || "" }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "projects"] });
      toast({ title: "Project deleted successfully" });
    },
  });

  const updateSiteContentMutation = useMutation({
    mutationFn: async ({ key, value, type }: { key: string; value: string; type: string }) => {
      const response = await fetch("/api/admin/site-content", {
        method: "PUT",
        body: JSON.stringify({ key, value, type }),
        headers: { 
          "Content-Type": "application/json",
          walletAddress: adminState.walletAddress || "" 
        }
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin", "site-content"] });
      toast({ title: "Site content updated successfully" });
    },
  });

  const handleAuthenticated = (walletAddress: string) => {
    setAdminState({ isAuthenticated: true, walletAddress });
    // Invalidate queries to refetch with new auth
    queryClient.invalidateQueries({ queryKey: ["admin"] });
  };

  const handleDisconnect = () => {
    setAdminState({ isAuthenticated: false });
  };

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
  };

  const handleTitleChange = (title: string, isNew = true) => {
    if (isNew) {
      setNewArticle(prev => ({
        ...prev,
        title,
        slug: generateSlug(title),
      }));
    }
  };

  // Filter functions
  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === "all" || 
                         (filterStatus === "published" && article.published) ||
                         (filterStatus === "draft" && !article.published);
    return matchesSearch && matchesFilter;
  });

  const filteredProjects = projects.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === "all" || 
                         (filterStatus === "published" && project.published) ||
                         (filterStatus === "draft" && !project.published);
    return matchesSearch && matchesFilter;
  });

  // Stats
  const stats = {
    totalArticles: articles.length,
    publishedArticles: articles.filter(a => a.published).length,
    featuredArticles: articles.filter(a => a.featured).length,
    totalProjects: projects.length,
    publishedProjects: projects.filter(p => p.published).length,
    featuredProjects: projects.filter(p => p.featured).length,
  };

  if (!adminState.isAuthenticated) {
    return (
      <div className="min-h-screen bg-[var(--space-blue)] flex items-center justify-center p-4">
        <WalletConnect
          onAuthenticated={handleAuthenticated}
          onDisconnect={handleDisconnect}
          isAuthenticated={adminState.isAuthenticated}
          walletAddress={adminState.walletAddress}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--space-blue)] text-white">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center mb-8 gap-4">
          <div>
            <h1 className="text-4xl font-bold text-gradient mb-2">
              Zaihash Admin Panel
            </h1>
            <p className="text-[var(--steel-gray)]">Manage your portfolio content and settings</p>
          </div>
          <WalletConnect
            onAuthenticated={handleAuthenticated}
            onDisconnect={handleDisconnect}
            isAuthenticated={adminState.isAuthenticated}
            walletAddress={adminState.walletAddress}
          />
        </div>

        {/* Search and Filter Bar */}
        <Card className="mb-8 bg-gradient-to-r from-[var(--dark-gray)] to-[var(--space-blue)] border-[var(--electric-purple)]/30">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[var(--steel-gray)]" />
                <Input
                  placeholder="Search articles, projects, or content..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-[var(--dark-gray)] border-[var(--steel-gray)]/30 text-white"
                />
              </div>
              <div className="flex gap-2">
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value as any)}
                  className="px-4 py-2 rounded-lg bg-[var(--dark-gray)] border border-[var(--steel-gray)]/30 text-white"
                >
                  <option value="all">All Status</option>
                  <option value="published">Published</option>
                  <option value="draft">Draft</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-[var(--dark-gray)] border border-[var(--electric-purple)]/30">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3Icon className="w-4 h-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="articles">Articles</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="new-article">New Article</TabsTrigger>
            <TabsTrigger value="new-project">New Project</TabsTrigger>
            <TabsTrigger value="site-content">Site Content</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="bg-gradient-to-br from-[var(--neon-green)]/20 to-[var(--dark-gray)] border-[var(--neon-green)]/30">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-[var(--steel-gray)]">Total Articles</p>
                      <p className="text-3xl font-bold text-white">{stats.totalArticles}</p>
                      <p className="text-xs text-[var(--neon-green)]">{stats.publishedArticles} published</p>
                    </div>
                    <div className="p-3 bg-[var(--neon-green)]/20 rounded-full">
                      <EditIcon className="w-6 h-6 text-[var(--neon-green)]" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-[var(--electric-purple)]/20 to-[var(--dark-gray)] border-[var(--electric-purple)]/30">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-[var(--steel-gray)]">Total Projects</p>
                      <p className="text-3xl font-bold text-white">{stats.totalProjects}</p>
                      <p className="text-xs text-[var(--electric-purple)]">{stats.publishedProjects} published</p>
                    </div>
                    <div className="p-3 bg-[var(--electric-purple)]/20 rounded-full">
                      <TrendingUpIcon className="w-6 h-6 text-[var(--electric-purple)]" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-500/20 to-[var(--dark-gray)] border-orange-500/30">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-[var(--steel-gray)]">Featured Content</p>
                      <p className="text-3xl font-bold text-white">{stats.featuredArticles + stats.featuredProjects}</p>
                      <p className="text-xs text-orange-400">{stats.featuredArticles} articles, {stats.featuredProjects} projects</p>
                    </div>
                    <div className="p-3 bg-orange-500/20 rounded-full">
                      <EyeIcon className="w-6 h-6 text-orange-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card className="bg-gradient-to-r from-[var(--dark-gray)] to-[var(--space-blue)] border-[var(--electric-purple)]/30">
              <CardHeader>
                <CardTitle className="text-xl text-white">Quick Actions</CardTitle>
                <CardDescription className="text-[var(--steel-gray)]">Common tasks to manage your content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Button 
                    onClick={() => setActiveTab("new-article")}
                    className="h-auto p-4 bg-[var(--neon-green)]/20 hover:bg-[var(--neon-green)]/30 border border-[var(--neon-green)]/30"
                  >
                    <div className="text-center">
                      <PlusIcon className="w-6 h-6 mx-auto mb-2 text-[var(--neon-green)]" />
                      <p className="text-sm font-medium">New Article</p>
                    </div>
                  </Button>
                  
                  <Button 
                    onClick={() => setActiveTab("new-project")}
                    className="h-auto p-4 bg-[var(--electric-purple)]/20 hover:bg-[var(--electric-purple)]/30 border border-[var(--electric-purple)]/30"
                  >
                    <div className="text-center">
                      <PlusIcon className="w-6 h-6 mx-auto mb-2 text-[var(--electric-purple)]" />
                      <p className="text-sm font-medium">New Project</p>
                    </div>
                  </Button>
                  
                  <Button 
                    onClick={() => setActiveTab("articles")}
                    className="h-auto p-4 bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/30"
                  >
                    <div className="text-center">
                      <EditIcon className="w-6 h-6 mx-auto mb-2 text-blue-400" />
                      <p className="text-sm font-medium">Manage Articles</p>
                    </div>
                  </Button>
                  
                  <Button 
                    onClick={() => setActiveTab("site-content")}
                    className="h-auto p-4 bg-yellow-500/20 hover:bg-yellow-500/30 border border-yellow-500/30"
                  >
                    <div className="text-center">
                      <SaveIcon className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
                      <p className="text-sm font-medium">Site Settings</p>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Recent Content */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gradient-to-br from-[var(--dark-gray)] to-[var(--space-blue)] border-[var(--electric-purple)]/30">
                <CardHeader>
                  <CardTitle className="text-lg text-white">Recent Articles</CardTitle>
                </CardHeader>
                <CardContent>
                  {articles.slice(0, 3).map((article: Article) => (
                    <div key={article.id} className="flex items-center justify-between py-3 border-b border-[var(--steel-gray)]/20 last:border-b-0">
                      <div className="flex-1">
                        <p className="font-medium text-white truncate">{article.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant={article.published ? "default" : "secondary"} className="text-xs">
                            {article.published ? "Published" : "Draft"}
                          </Badge>
                          {article.featured && <Badge variant="outline" className="text-xs">Featured</Badge>}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setEditingArticle(article);
                          setActiveTab("articles");
                        }}
                        className="ml-2"
                      >
                        <EditIcon className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  {articles.length === 0 && (
                    <p className="text-[var(--steel-gray)] text-center py-4">No articles yet</p>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-[var(--dark-gray)] to-[var(--space-blue)] border-[var(--electric-purple)]/30">
                <CardHeader>
                  <CardTitle className="text-lg text-white">Recent Projects</CardTitle>
                </CardHeader>
                <CardContent>
                  {projects.slice(0, 3).map((project: Project) => (
                    <div key={project.id} className="flex items-center justify-between py-3 border-b border-[var(--steel-gray)]/20 last:border-b-0">
                      <div className="flex-1">
                        <p className="font-medium text-white truncate">{project.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant={project.published ? "default" : "secondary"} className="text-xs">
                            {project.published ? "Published" : "Draft"}
                          </Badge>
                          {project.featured && <Badge variant="outline" className="text-xs">Featured</Badge>}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setEditingProject(project);
                          setActiveTab("projects");
                        }}
                        className="ml-2"
                      >
                        <EditIcon className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  {projects.length === 0 && (
                    <p className="text-[var(--steel-gray)] text-center py-4">No projects yet</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="articles" className="space-y-4">
            <Card className="bg-gradient-to-br from-[var(--dark-gray)] to-[var(--space-blue)] border-[var(--electric-purple)]/30">
              <CardHeader>
                <CardTitle className="text-xl text-white">Manage Articles</CardTitle>
                <CardDescription className="text-[var(--steel-gray)]">Create, edit, and manage your blog posts</CardDescription>
              </CardHeader>
              <CardContent>
                {articlesLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin w-8 h-8 border-2 border-[var(--electric-purple)] border-t-transparent rounded-full mx-auto mb-4"></div>
                    <p className="text-[var(--steel-gray)]">Loading articles...</p>
                  </div>
                ) : filteredArticles && filteredArticles.length > 0 ? (
                  <div className="space-y-4">
                    {filteredArticles.map((article: Article) => (
                      <div key={article.id} className="flex items-center justify-between p-4 border border-[var(--electric-purple)]/30 rounded-lg bg-[var(--dark-gray)]/50 hover:bg-[var(--electric-purple)]/10 transition-colors">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-white">{article.title}</h3>
                            <div className="flex items-center gap-2">
                              <Badge variant={article.published ? "default" : "secondary"} className="text-xs">
                                {article.published ? "Published" : "Draft"}
                              </Badge>
                              {article.featured && (
                                <Badge variant="outline" className="text-xs bg-[var(--neon-green)]/20 text-[var(--neon-green)] border-[var(--neon-green)]/30">
                                  Featured
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-[var(--steel-gray)] mb-2 line-clamp-2">{article.excerpt}</p>
                          {article.tags && article.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {article.tags.slice(0, 3).map((tag) => (
                                <span 
                                  key={tag}
                                  className="text-xs bg-[var(--electric-purple)]/20 text-[var(--electric-purple)] px-2 py-1 rounded-full"
                                >
                                  #{tag}
                                </span>
                              ))}
                              {article.tags.length > 3 && (
                                <span className="text-xs text-[var(--steel-gray)]">+{article.tags.length - 3} more</span>
                              )}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setEditingArticle(article)}
                            className="border-[var(--neon-green)]/30 hover:bg-[var(--neon-green)]/20"
                          >
                            <EditIcon className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open(`/articles/${article.slug}`, '_blank')}
                            className="border-blue-500/30 hover:bg-blue-500/20"
                          >
                            <EyeIcon className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => deleteArticleMutation.mutate(article.id)}
                            disabled={deleteArticleMutation.isPending}
                            className="bg-red-600/20 hover:bg-red-600/30 border-red-500/30"
                          >
                            <TrashIcon className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 mx-auto mb-4 bg-[var(--electric-purple)]/20 rounded-full flex items-center justify-center">
                      <EditIcon className="w-8 h-8 text-[var(--electric-purple)]" />
                    </div>
                    <h3 className="text-lg font-medium text-white mb-2">
                      {searchTerm || filterStatus !== "all" ? "No articles match your search" : "No articles yet"}
                    </h3>
                    <p className="text-[var(--steel-gray)] mb-6">
                      {searchTerm || filterStatus !== "all" 
                        ? "Try adjusting your search terms or filters" 
                        : "Create your first article to get started"
                      }
                    </p>
                    <Button 
                      onClick={() => setActiveTab("new-article")}
                      className="bg-gradient-to-r from-[var(--neon-green)] to-[var(--electric-purple)] hover:from-[var(--neon-green)]/80 hover:to-[var(--electric-purple)]/80"
                    >
                      <PlusIcon className="w-4 h-4 mr-2" />
                      Create New Article
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="projects" className="space-y-4">
            <Card className="bg-gradient-to-br from-[var(--dark-gray)] to-[var(--space-blue)] border-[var(--electric-purple)]/30">
              <CardHeader>
                <CardTitle className="text-xl text-white">Manage Projects</CardTitle>
                <CardDescription className="text-[var(--steel-gray)]">Create, edit, and manage your portfolio projects</CardDescription>
              </CardHeader>
              <CardContent>
                {projectsLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin w-8 h-8 border-2 border-[var(--electric-purple)] border-t-transparent rounded-full mx-auto mb-4"></div>
                    <p className="text-[var(--steel-gray)]">Loading projects...</p>
                  </div>
                ) : filteredProjects && filteredProjects.length > 0 ? (
                  <div className="space-y-4">
                    {filteredProjects.map((project: Project) => (
                      <div key={project.id} className="flex items-center justify-between p-4 border border-[var(--electric-purple)]/30 rounded-lg bg-[var(--dark-gray)]/50 hover:bg-[var(--electric-purple)]/10 transition-colors">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="font-semibold text-white">{project.title}</h3>
                            <div className="flex items-center gap-2">
                              <Badge variant={project.published ? "default" : "secondary"} className="text-xs">
                                {project.published ? "Published" : "Draft"}
                              </Badge>
                              {project.featured && (
                                <Badge variant="outline" className="text-xs bg-[var(--neon-green)]/20 text-[var(--neon-green)] border-[var(--neon-green)]/30">
                                  Featured
                                </Badge>
                              )}
                              {project.category && (
                                <Badge variant="outline" className="text-xs bg-[var(--electric-purple)]/20 text-[var(--electric-purple)] border-[var(--electric-purple)]/30">
                                  {project.category}
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-[var(--steel-gray)] mb-2 line-clamp-2">{project.shortDescription}</p>
                          {project.technologies && project.technologies.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {project.technologies.slice(0, 4).map((tech) => (
                                <span 
                                  key={tech}
                                  className="text-xs bg-blue-500/20 text-blue-400 px-2 py-1 rounded-full"
                                >
                                  {tech}
                                </span>
                              ))}
                              {project.technologies.length > 4 && (
                                <span className="text-xs text-[var(--steel-gray)]">+{project.technologies.length - 4} more</span>
                              )}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setEditingProject(project)}
                            className="border-[var(--neon-green)]/30 hover:bg-[var(--neon-green)]/20"
                          >
                            <EditIcon className="w-4 h-4" />
                          </Button>
                          {project.liveUrl && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => window.open(project.liveUrl, '_blank')}
                              className="border-blue-500/30 hover:bg-blue-500/20"
                            >
                              <ExternalLinkIcon className="w-4 h-4" />
                            </Button>
                          )}
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => deleteProjectMutation.mutate(project.id)}
                            disabled={deleteProjectMutation.isPending}
                            className="bg-red-600/20 hover:bg-red-600/30 border-red-500/30"
                          >
                            <TrashIcon className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 mx-auto mb-4 bg-[var(--electric-purple)]/20 rounded-full flex items-center justify-center">
                      <TrendingUpIcon className="w-8 h-8 text-[var(--electric-purple)]" />
                    </div>
                    <h3 className="text-lg font-medium text-white mb-2">
                      {searchTerm || filterStatus !== "all" ? "No projects match your search" : "No projects yet"}
                    </h3>
                    <p className="text-[var(--steel-gray)] mb-6">
                      {searchTerm || filterStatus !== "all" 
                        ? "Try adjusting your search terms or filters" 
                        : "Create your first project to showcase your work"
                      }
                    </p>
                    <Button 
                      onClick={() => setActiveTab("new-project")}
                      className="bg-gradient-to-r from-[var(--neon-green)] to-[var(--electric-purple)] hover:from-[var(--neon-green)]/80 hover:to-[var(--electric-purple)]/80"
                    >
                      <PlusIcon className="w-4 h-4 mr-2" />
                      Create New Project
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="new-article" className="space-y-4">
            <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
              <CardHeader>
                <CardTitle>Create New Article</CardTitle>
                <CardDescription>Write a new blog post</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      value={newArticle.title}
                      onChange={(e) => handleTitleChange(e.target.value)}
                      placeholder="Article title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="slug">Slug</Label>
                    <Input
                      id="slug"
                      value={newArticle.slug}
                      onChange={(e) => setNewArticle(prev => ({ ...prev, slug: e.target.value }))}
                      placeholder="article-slug"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="excerpt">Excerpt</Label>
                  <Textarea
                    id="excerpt"
                    value={newArticle.excerpt}
                    onChange={(e) => setNewArticle(prev => ({ ...prev, excerpt: e.target.value }))}
                    placeholder="Brief description of the article"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="content">Content</Label>
                  <Textarea
                    id="content"
                    value={newArticle.content}
                    onChange={(e) => setNewArticle(prev => ({ ...prev, content: e.target.value }))}
                    placeholder="Article content (supports Markdown)"
                    rows={10}
                  />
                </div>

                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="featured"
                      checked={newArticle.featured}
                      onCheckedChange={(checked) => setNewArticle(prev => ({ ...prev, featured: checked }))}
                    />
                    <Label htmlFor="featured">Featured</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="published"
                      checked={newArticle.published}
                      onCheckedChange={(checked) => setNewArticle(prev => ({ ...prev, published: checked }))}
                    />
                    <Label htmlFor="published">Published</Label>
                  </div>
                </div>

                <Button
                  onClick={() => createArticleMutation.mutate(newArticle)}
                  disabled={createArticleMutation.isPending || !newArticle.title}
                  className="w-full"
                >
                  <PlusIcon className="w-4 h-4 mr-2" />
                  {createArticleMutation.isPending ? "Creating..." : "Create Article"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="new-project" className="space-y-4">
            <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
              <CardHeader>
                <CardTitle>Create New Project</CardTitle>
                <CardDescription>Add a new project to your portfolio</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="project-title">Title</Label>
                    <Input
                      id="project-title"
                      value={newProject.title}
                      onChange={(e) => setNewProject(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Project title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="project-category">Category</Label>
                    <Input
                      id="project-category"
                      value={newProject.category}
                      onChange={(e) => setNewProject(prev => ({ ...prev, category: e.target.value }))}
                      placeholder="e.g., webapp, mobile, ai, blockchain"
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="project-short-desc">Short Description</Label>
                  <Textarea
                    id="project-short-desc"
                    value={newProject.shortDescription}
                    onChange={(e) => setNewProject(prev => ({ ...prev, shortDescription: e.target.value }))}
                    placeholder="Brief description for project cards"
                    rows={2}
                  />
                </div>

                <div>
                  <Label htmlFor="project-desc">Full Description</Label>
                  <Textarea
                    id="project-desc"
                    value={newProject.description}
                    onChange={(e) => setNewProject(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Detailed project description"
                    rows={4}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="project-live">Live URL</Label>
                    <Input
                      id="project-live"
                      value={newProject.liveUrl}
                      onChange={(e) => setNewProject(prev => ({ ...prev, liveUrl: e.target.value }))}
                      placeholder="https://example.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="project-github">GitHub URL</Label>
                    <Input
                      id="project-github"
                      value={newProject.githubUrl}
                      onChange={(e) => setNewProject(prev => ({ ...prev, githubUrl: e.target.value }))}
                      placeholder="https://github.com/username/repo"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="project-image">Image URL</Label>
                  <Input
                    id="project-image"
                    value={newProject.imageUrl}
                    onChange={(e) => setNewProject(prev => ({ ...prev, imageUrl: e.target.value }))}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                <div>
                  <Label htmlFor="project-tech">Technologies (comma-separated)</Label>
                  <Input
                    id="project-tech"
                    value={newProject.technologies.join(", ")}
                    onChange={(e) => setNewProject(prev => ({ 
                      ...prev, 
                      technologies: e.target.value.split(",").map(t => t.trim()).filter(Boolean)
                    }))}
                    placeholder="React, TypeScript, Node.js, PostgreSQL"
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="project-order">Display Order</Label>
                    <Input
                      id="project-order"
                      type="number"
                      value={newProject.orderIndex}
                      onChange={(e) => setNewProject(prev => ({ ...prev, orderIndex: parseInt(e.target.value) || 0 }))}
                      placeholder="0"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="project-featured"
                      checked={newProject.featured}
                      onCheckedChange={(checked) => setNewProject(prev => ({ ...prev, featured: checked }))}
                    />
                    <Label htmlFor="project-featured">Featured</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="project-published"
                      checked={newProject.published}
                      onCheckedChange={(checked) => setNewProject(prev => ({ ...prev, published: checked }))}
                    />
                    <Label htmlFor="project-published">Published</Label>
                  </div>
                </div>

                <Button
                  onClick={() => createProjectMutation.mutate(newProject)}
                  disabled={createProjectMutation.isPending || !newProject.title || !newProject.category}
                  className="w-full"
                >
                  <PlusIcon className="w-4 h-4 mr-2" />
                  {createProjectMutation.isPending ? "Creating..." : "Create Project"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="site-content" className="space-y-4">
            <Card className="bg-black/20 backdrop-blur-sm border-purple-500/20">
              <CardHeader>
                <CardTitle>Site Content</CardTitle>
                <CardDescription>Manage social links and website content</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {siteContentLoading ? (
                  <div>Loading site content...</div>
                ) : (
                  <div className="space-y-4">
                    {siteContent.map((content: SiteContent) => (
                      <div key={content.id} className="space-y-2">
                        <Label htmlFor={content.key}>{content.key.replace(/_/g, " ").toUpperCase()}</Label>
                        <div className="flex gap-2">
                          <Input
                            id={content.key}
                            value={siteContentEdits[content.key] ?? content.value}
                            onChange={(e) => setSiteContentEdits(prev => ({
                              ...prev,
                              [content.key]: e.target.value
                            }))}
                            placeholder={content.value}
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => updateSiteContentMutation.mutate({
                              key: content.key,
                              value: siteContentEdits[content.key] ?? content.value,
                              type: content.type
                            })}
                            disabled={updateSiteContentMutation.isPending}
                          >
                            <SaveIcon className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}