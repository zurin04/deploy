import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Plus, Trash2, Printer, Download, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ReceiptItem {
  name: string;
  quantity: number;
  price: number;
  total: number;
}

interface ReceiptData {
  receiptNumber: string;
  businessName: string;
  businessAddress: string;
  businessPhone: string;
  businessEmail: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  items: ReceiptItem[];
  subtotal: string;
  tax: string;
  discount: string;
  total: string;
  paymentMethod: string;
  notes: string;
}

export default function ReceiptGenerator() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const printRef = useRef<HTMLDivElement>(null);

  // Fetch business settings
  const { data: businessSettings } = useQuery({
    queryKey: ['/api/business-settings'],
  });

  const [receiptData, setReceiptData] = useState<ReceiptData>({
    receiptNumber: `RCP-${Date.now()}`,
    businessName: "Your Business Name",
    businessAddress: businessSettings?.address || "",
    businessPhone: businessSettings?.phone || "",
    businessEmail: businessSettings?.email || "",
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    items: [{ name: "", quantity: 1, price: 0, total: 0 }],
    subtotal: "0.00",
    tax: "0.00",
    discount: "0.00",
    total: "0.00",
    paymentMethod: "Cash",
    notes: "",
  });

  const saveReceiptMutation = useMutation({
    mutationFn: async (data: ReceiptData) => {
      return apiRequest('/api/receipts', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      toast({ title: "Receipt saved successfully!" });
      queryClient.invalidateQueries({ queryKey: ['/api/receipts'] });
    },
    onError: () => {
      toast({ title: "Failed to save receipt", variant: "destructive" });
    },
  });

  const addItem = () => {
    setReceiptData(prev => ({
      ...prev,
      items: [...prev.items, { name: "", quantity: 1, price: 0, total: 0 }]
    }));
  };

  const removeItem = (index: number) => {
    if (receiptData.items.length === 1) return;
    setReceiptData(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index)
    }));
    calculateTotals();
  };

  const updateItem = (index: number, field: keyof ReceiptItem, value: string | number) => {
    const updatedItems = [...receiptData.items];
    updatedItems[index] = { ...updatedItems[index], [field]: value };
    
    if (field === 'quantity' || field === 'price') {
      updatedItems[index].total = updatedItems[index].quantity * updatedItems[index].price;
    }
    
    setReceiptData(prev => ({ ...prev, items: updatedItems }));
    calculateTotals();
  };

  const calculateTotals = () => {
    setTimeout(() => {
      const subtotal = receiptData.items.reduce((sum, item) => sum + item.total, 0);
      const discount = parseFloat(receiptData.discount) || 0;
      const taxRate = parseFloat(businessSettings?.taxRate || "8.25") / 100;
      const taxAmount = (subtotal - discount) * taxRate;
      const total = subtotal - discount + taxAmount;

      setReceiptData(prev => ({
        ...prev,
        subtotal: subtotal.toFixed(2),
        tax: taxAmount.toFixed(2),
        total: total.toFixed(2)
      }));
    }, 0);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    // Create a new window with just the receipt content for PDF generation
    const printWindow = window.open('', '_blank');
    if (printWindow && printRef.current) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Receipt ${receiptData.receiptNumber}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              .receipt { max-width: 400px; margin: 0 auto; }
              .header { text-align: center; margin-bottom: 20px; }
              .business-name { font-size: 18px; font-weight: bold; }
              .section { margin: 15px 0; }
              .items-table { width: 100%; border-collapse: collapse; }
              .items-table th, .items-table td { padding: 5px; text-align: left; border-bottom: 1px solid #ddd; }
              .totals { text-align: right; margin-top: 15px; }
              .total-line { font-weight: bold; font-size: 16px; }
              @media print { body { margin: 0; } }
            </style>
          </head>
          <body>
            ${printRef.current.innerHTML}
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.focus();
      printWindow.print();
      printWindow.close();
    }
  };

  const handleSave = () => {
    saveReceiptMutation.mutate(receiptData);
  };

  return (
    <div className="container mx-auto p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Input Form */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Create New Receipt
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Receipt Number */}
            <div>
              <Label htmlFor="receiptNumber">Receipt Number</Label>
              <Input
                id="receiptNumber"
                value={receiptData.receiptNumber}
                onChange={(e) => setReceiptData(prev => ({ ...prev, receiptNumber: e.target.value }))}
              />
            </div>

            {/* Business Information */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="businessName">Business Name</Label>
                <Input
                  id="businessName"
                  value={receiptData.businessName}
                  onChange={(e) => setReceiptData(prev => ({ ...prev, businessName: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="businessPhone">Phone</Label>
                <Input
                  id="businessPhone"
                  value={receiptData.businessPhone}
                  onChange={(e) => setReceiptData(prev => ({ ...prev, businessPhone: e.target.value }))}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="businessAddress">Business Address</Label>
              <Textarea
                id="businessAddress"
                value={receiptData.businessAddress}
                onChange={(e) => setReceiptData(prev => ({ ...prev, businessAddress: e.target.value }))}
              />
            </div>

            {/* Customer Information */}
            <Separator />
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="customerName">Customer Name</Label>
                <Input
                  id="customerName"
                  value={receiptData.customerName}
                  onChange={(e) => setReceiptData(prev => ({ ...prev, customerName: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="customerPhone">Customer Phone</Label>
                <Input
                  id="customerPhone"
                  value={receiptData.customerPhone}
                  onChange={(e) => setReceiptData(prev => ({ ...prev, customerPhone: e.target.value }))}
                />
              </div>
            </div>

            {/* Items */}
            <Separator />
            <div>
              <Label>Items</Label>
              {receiptData.items.map((item, index) => (
                <div key={index} className="grid grid-cols-12 gap-2 mt-2">
                  <div className="col-span-5">
                    <Input
                      placeholder="Item name"
                      value={item.name}
                      onChange={(e) => updateItem(index, 'name', e.target.value)}
                    />
                  </div>
                  <div className="col-span-2">
                    <Input
                      type="number"
                      placeholder="Qty"
                      value={item.quantity}
                      onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <div className="col-span-2">
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="Price"
                      value={item.price}
                      onChange={(e) => updateItem(index, 'price', parseFloat(e.target.value) || 0)}
                    />
                  </div>
                  <div className="col-span-2">
                    <Input
                      value={item.total.toFixed(2)}
                      readOnly
                      className="bg-gray-50"
                    />
                  </div>
                  <div className="col-span-1">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeItem(index)}
                      disabled={receiptData.items.length === 1}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              <Button variant="outline" onClick={addItem} className="mt-2">
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
            </div>

            {/* Payment and Notes */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="paymentMethod">Payment Method</Label>
                <Input
                  id="paymentMethod"
                  value={receiptData.paymentMethod}
                  onChange={(e) => setReceiptData(prev => ({ ...prev, paymentMethod: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="discount">Discount ($)</Label>
                <Input
                  id="discount"
                  type="number"
                  step="0.01"
                  value={receiptData.discount}
                  onChange={(e) => {
                    setReceiptData(prev => ({ ...prev, discount: e.target.value }));
                    calculateTotals();
                  }}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={receiptData.notes}
                onChange={(e) => setReceiptData(prev => ({ ...prev, notes: e.target.value }))}
              />
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={saveReceiptMutation.isPending}>
                <Save className="h-4 w-4 mr-2" />
                Save Receipt
              </Button>
              <Button onClick={handlePrint} variant="outline">
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button onClick={handleDownloadPDF} variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Download PDF
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Receipt Preview */}
      <div className="print:col-span-full">
        <Card className="print:shadow-none print:border-none">
          <CardContent className="p-6" ref={printRef}>
            <div className="receipt max-w-md mx-auto bg-white">
              {/* Header */}
              <div className="header text-center mb-6">
                <div className="business-name text-xl font-bold">{receiptData.businessName}</div>
                {receiptData.businessAddress && (
                  <div className="text-sm text-gray-600 mt-1">{receiptData.businessAddress}</div>
                )}
                <div className="text-sm text-gray-600">
                  {receiptData.businessPhone && <span>Tel: {receiptData.businessPhone}</span>}
                  {receiptData.businessEmail && <span className="ml-4">Email: {receiptData.businessEmail}</span>}
                </div>
              </div>

              <Separator className="my-4" />

              {/* Receipt Info */}
              <div className="section flex justify-between text-sm">
                <div>
                  <div>Receipt: {receiptData.receiptNumber}</div>
                  <div>Date: {new Date().toLocaleDateString()}</div>
                  <div>Time: {new Date().toLocaleTimeString()}</div>
                </div>
                <div className="text-right">
                  {receiptData.customerName && <div>Customer: {receiptData.customerName}</div>}
                  {receiptData.customerPhone && <div>Phone: {receiptData.customerPhone}</div>}
                </div>
              </div>

              <Separator className="my-4" />

              {/* Items */}
              <div className="section">
                <table className="items-table w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left">Item</th>
                      <th className="text-right">Qty</th>
                      <th className="text-right">Price</th>
                      <th className="text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {receiptData.items.map((item, index) => (
                      <tr key={index}>
                        <td>{item.name}</td>
                        <td className="text-right">{item.quantity}</td>
                        <td className="text-right">${item.price.toFixed(2)}</td>
                        <td className="text-right">${item.total.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <Separator className="my-4" />

              {/* Totals */}
              <div className="totals text-sm space-y-1">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>${receiptData.subtotal}</span>
                </div>
                {parseFloat(receiptData.discount) > 0 && (
                  <div className="flex justify-between">
                    <span>Discount:</span>
                    <span>-${receiptData.discount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Tax:</span>
                  <span>${receiptData.tax}</span>
                </div>
                <Separator className="my-2" />
                <div className="total-line flex justify-between text-lg font-bold">
                  <span>Total:</span>
                  <span>${receiptData.total}</span>
                </div>
                <div className="flex justify-between mt-2">
                  <span>Payment Method:</span>
                  <span>{receiptData.paymentMethod}</span>
                </div>
              </div>

              {/* Notes */}
              {receiptData.notes && (
                <>
                  <Separator className="my-4" />
                  <div className="section text-sm">
                    <div className="font-semibold">Notes:</div>
                    <div>{receiptData.notes}</div>
                  </div>
                </>
              )}

              <Separator className="my-4" />

              {/* Footer */}
              <div className="text-center text-xs text-gray-500">
                <div>Thank you for your business!</div>
                <div className="mt-2">{businessSettings?.receiptFooter || "Visit us again soon"}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}