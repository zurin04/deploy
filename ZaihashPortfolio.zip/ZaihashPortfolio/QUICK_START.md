# Quick Start Guide

## Current Status
The domain `receipt.zaihash.xyz` is not yet configured. Here's how to set it up:

## Step 1: DNS Configuration
Add these DNS records in your domain registrar:
```
Type: A
Name: receipt
Value: [Your VPS IP Address]
TTL: 300
```

## Step 2: Upload Files to VPS
```bash
# Portfolio files → /opt/zaihash-portfolio/
# Receipt Pro files → /opt/receipt-pro/
```

## Step 3: Deploy
```bash
sudo ./deploy-all.sh
```

## Step 4: Verify
After deployment, both sites will be accessible:
- Portfolio: http://zaihash.xyz
- Receipt Pro: http://receipt.zaihash.xyz

## Troubleshooting
Run verification script:
```bash
./verify-deployment.sh
```

The deployment script handles:
- Node.js installation
- PostgreSQL setup
- PM2 process management
- Nginx configuration
- SSL certificate preparation