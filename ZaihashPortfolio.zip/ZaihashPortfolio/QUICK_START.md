# One-Click Setup Guide

## Prerequisites
1. Ubuntu 20.04+ VPS with root access
2. DNS records pointing to your VPS:
   - `zaihash.xyz` → Your VPS IP
   - `receipt.zaihash.xyz` → Your VPS IP

## One-Click Deployment

1. **Download and extract** your Replit project zip
2. **Upload** to your VPS and extract
3. **Run setup**:
```bash
sudo ./setup.sh
```

That's it! The script automatically:
- Installs Node.js, PostgreSQL, PM2, Nginx
- Sets up databases and users
- Deploys both applications
- Configures domain routing

## After Setup
Your sites will be live at:
- Portfolio: http://zaihash.xyz
- Receipt Pro: http://receipt.zaihash.xyz

## Enable HTTPS (Optional)
```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d zaihash.xyz -d receipt.zaihash.xyz
```

## Management
```bash
pm2 status          # Check applications
pm2 logs            # View logs
pm2 restart all     # Restart both apps
```